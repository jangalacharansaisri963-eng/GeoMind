import { DynamicEvent, DynamicEventType } from '../types/game';

export const DYNAMIC_EVENTS: Record<DynamicEventType, DynamicEvent> = {
  GOLD_RUSH: {
    id: 'GOLD_RUSH',
    name: 'Gold Rush Mania',
    badge: '3X COINS',
    tagline: 'All coins turn to shimmering pure gold (+5★)!',
    description: 'Golden nuggets rain from the skies. Every coin you spot is worth 5 Gold Coins with elevated spawn rates.',
    icon: 'Coins',
    bannerColor: 'from-amber-500 via-yellow-400 to-amber-600',
    glowColor: '#fbbf24',
    bgTint: 'rgba(251, 191, 36, 0.08)',
    gravityMultiplierMod: 1.0,
    speedMultiplierMod: 1.0,
    coinRateMod: 2.5,
    allGoldCoins: true,
    doubleScoreMod: false,
    freeShieldOnStart: false,
    activeMinutesDuration: 15,
  },
  NEBULA_DRIFT: {
    id: 'NEBULA_DRIFT',
    name: 'Nebula Low Gravity',
    badge: 'LOW GRAVITY',
    tagline: 'Float through space with 35% reduced gravity & cosmic trails!',
    description: 'A passing cosmic nebula alters atmosphere density. Your bird glides gracefully with ethereal stardust.',
    icon: 'Sparkles',
    bannerColor: 'from-purple-600 via-pink-500 to-indigo-600',
    glowColor: '#ec4899',
    bgTint: 'rgba(168, 85, 247, 0.08)',
    gravityMultiplierMod: 0.65,
    speedMultiplierMod: 0.95,
    coinRateMod: 1.0,
    allGoldCoins: false,
    doubleScoreMod: false,
    freeShieldOnStart: false,
    activeMinutesDuration: 15,
  },
  DOUBLE_SCORE: {
    id: 'DOUBLE_SCORE',
    name: 'Double Points Frenzy',
    badge: '2X SCORE',
    tagline: 'Every cleared pipe scores +2 points on leaderboard!',
    description: 'High-score season has begun. Blast your personal records to pieces with double clearance points.',
    icon: 'Flame',
    bannerColor: 'from-orange-500 via-rose-500 to-red-600',
    glowColor: '#f43f5e',
    bgTint: 'rgba(244, 63, 94, 0.08)',
    gravityMultiplierMod: 1.0,
    speedMultiplierMod: 1.0,
    coinRateMod: 1.2,
    allGoldCoins: false,
    doubleScoreMod: true,
    freeShieldOnStart: false,
    activeMinutesDuration: 15,
  },
  SHIELD_CARNIVAL: {
    id: 'SHIELD_CARNIVAL',
    name: 'Aegis Shield Festival',
    badge: 'FREE SHIELD',
    tagline: 'Every bird receives a divine protective barrier on spawn!',
    description: 'Ancient guardians bless your flight. Take one free pipe hit per flight without crashing!',
    icon: 'ShieldCheck',
    bannerColor: 'from-emerald-500 via-teal-400 to-cyan-600',
    glowColor: '#10b981',
    bgTint: 'rgba(16, 185, 129, 0.08)',
    gravityMultiplierMod: 1.0,
    speedMultiplierMod: 1.0,
    coinRateMod: 1.0,
    allGoldCoins: false,
    doubleScoreMod: false,
    freeShieldOnStart: true,
    activeMinutesDuration: 15,
  },
  TURBO_SPEED: {
    id: 'TURBO_SPEED',
    name: 'Hyper Velocity Rush',
    badge: '2.5X BONUS',
    tagline: '1.25x flight speed for adrenaline flyers + double coin rewards!',
    description: 'Intense gale winds push your reflexes to the limit. High risk, immense reward!',
    icon: 'Zap',
    bannerColor: 'from-cyan-500 via-blue-500 to-violet-600',
    glowColor: '#06b6d4',
    bgTint: 'rgba(6, 182, 212, 0.08)',
    gravityMultiplierMod: 1.05,
    speedMultiplierMod: 1.25,
    coinRateMod: 2.0,
    allGoldCoins: false,
    doubleScoreMod: true,
    freeShieldOnStart: false,
    activeMinutesDuration: 15,
  },
  GRAVITY_SURGE: {
    id: 'GRAVITY_SURGE',
    name: 'Solar Supercharge',
    badge: 'SUPER FLAP',
    tagline: 'Supercharged wing power with fiery sonic blastwaves!',
    description: 'Solar flares energize your wings with explosive lift and wide golden coin rings.',
    icon: 'Sun',
    bannerColor: 'from-amber-600 via-orange-500 to-yellow-500',
    glowColor: '#f59e0b',
    bgTint: 'rgba(245, 158, 11, 0.08)',
    gravityMultiplierMod: 1.15,
    speedMultiplierMod: 1.05,
    coinRateMod: 1.5,
    allGoldCoins: false,
    doubleScoreMod: false,
    freeShieldOnStart: false,
    activeMinutesDuration: 15,
  },
};

export const EVENT_ROTATION_ORDER: DynamicEventType[] = [
  'GOLD_RUSH',
  'NEBULA_DRIFT',
  'DOUBLE_SCORE',
  'SHIELD_CARNIVAL',
  'TURBO_SPEED',
  'GRAVITY_SURGE',
];

/**
 * Calculates current active dynamic event based on timestamp
 * Cycles event every 15 minutes smoothly
 */
export function getCurrentDynamicEvent(): {
  event: DynamicEvent;
  timeRemainingSeconds: number;
  progressPercent: number;
} {
  const now = Date.now();
  const eventDurationMs = 15 * 60 * 1000; // 15 minutes
  const totalEvents = EVENT_ROTATION_ORDER.length;

  const currentCycleIndex = Math.floor(now / eventDurationMs) % totalEvents;
  const eventKey = EVENT_ROTATION_ORDER[currentCycleIndex];
  const event = DYNAMIC_EVENTS[eventKey] || DYNAMIC_EVENTS.GOLD_RUSH;

  const timeElapsedInCycle = now % eventDurationMs;
  const timeRemainingSeconds = Math.max(0, Math.floor((eventDurationMs - timeElapsedInCycle) / 1000));
  const progressPercent = Math.min(100, Math.max(0, (timeElapsedInCycle / eventDurationMs) * 100));

  return {
    event,
    timeRemainingSeconds,
    progressPercent,
  };
}
