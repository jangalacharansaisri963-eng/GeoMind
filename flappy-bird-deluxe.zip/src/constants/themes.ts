import { ThemeConfig } from '../types/game';

export const THEMES: ThemeConfig[] = [
  {
    id: 'day',
    name: 'Sunny Meadow',
    skyTop: '#38BDF8', // Cyan-blue
    skyBottom: '#BAE6FD',
    mountainsColor: '#7DD3FC',
    cityColor: '#93C5FD',
    treesColor: '#86EFAC',
    groundTop: '#4ADE80',
    groundBody: '#D97706', // Retro warm dirt
    pipeColor: '#22C55E', // Classic retro green pipe
    pipeHighlight: '#86EFAC',
    pipeRim: '#15803D',
    pipeDark: '#166534',
    cloudAlpha: 0.85,
    ambientLight: 'rgba(255, 255, 255, 0.05)',
    weather: 'none',
  },
  {
    id: 'sunset',
    name: 'Twilight Ridge',
    skyTop: '#4C1D95', // Deep purple
    skyBottom: '#FB923C', // Warm orange
    mountainsColor: '#831843',
    cityColor: '#9F1239',
    treesColor: '#BE123C',
    groundTop: '#EA580C',
    groundBody: '#7C2D12',
    pipeColor: '#D97706',
    pipeHighlight: '#FDE68A',
    pipeRim: '#92400E',
    pipeDark: '#78350F',
    cloudAlpha: 0.6,
    ambientLight: 'rgba(251, 146, 60, 0.15)',
    weather: 'petals',
  },
  {
    id: 'cyber',
    name: 'Neon Metropolis',
    skyTop: '#0F172A',
    skyBottom: '#312E81',
    mountainsColor: '#1E1B4B',
    cityColor: '#4338CA',
    treesColor: '#06B6D4',
    groundTop: '#EC4899',
    groundBody: '#1E1B4B',
    pipeColor: '#06B6D4',
    pipeHighlight: '#67E8F9',
    pipeRim: '#0891B2',
    pipeDark: '#164E63',
    cloudAlpha: 0.3,
    ambientLight: 'rgba(6, 182, 212, 0.2)',
    weather: 'cyberGrid',
  },
  {
    id: 'midnight',
    name: 'Moonlit Forest',
    skyTop: '#020617',
    skyBottom: '#1E293B',
    mountainsColor: '#0F172A',
    cityColor: '#1E293B',
    treesColor: '#10B981',
    groundTop: '#059669',
    groundBody: '#0F172A',
    pipeColor: '#6366F1',
    pipeHighlight: '#A5B4FC',
    pipeRim: '#4338CA',
    pipeDark: '#312E81',
    cloudAlpha: 0.4,
    ambientLight: 'rgba(99, 102, 241, 0.15)',
    weather: 'fireflies',
  },
  {
    id: 'cosmic',
    name: 'Astral Cosmos',
    skyTop: '#050515',
    skyBottom: '#2E1065',
    mountainsColor: '#3B0764',
    cityColor: '#581C87',
    treesColor: '#7E22CE',
    groundTop: '#A855F7',
    groundBody: '#1E0E38',
    pipeColor: '#F59E0B',
    pipeHighlight: '#FDE68A',
    pipeRim: '#B45309',
    pipeDark: '#78350F',
    cloudAlpha: 0.35,
    ambientLight: 'rgba(168, 85, 247, 0.25)',
    weather: 'stars',
  }
];

export const getThemeById = (id: string): ThemeConfig => {
  return THEMES.find(t => t.id === id) || THEMES[0];
};
