import { PlayerStats, GameSettings, LeaderboardEntry } from '../types/game';

const STATS_KEY = 'flappy_deluxe_stats_v1';
const SETTINGS_KEY = 'flappy_deluxe_settings_v1';
const LEADERBOARD_KEY = 'flappy_deluxe_leaderboard_v1';

export const DEFAULT_STATS: PlayerStats = {
  highScore: 0,
  totalCoins: 50, // Starting gift coins for testing shop
  gamesPlayed: 0,
  totalPipesPassed: 0,
  totalCoinsCollected: 0,
  totalFlaps: 0,
  unlockedBirds: ['pip'],
  selectedBirdId: 'pip',
  completedQuestsCount: 0,
};

export const DEFAULT_SETTINGS: GameSettings = {
  playerName: 'AceFlyer',
  sound: {
    masterVolume: 0.8,
    sfxVolume: 0.8,
    bgmVolume: 0.5,
    sfxEnabled: true,
    bgmEnabled: true,
  },
  graphics: {
    particlesEnabled: true,
    screenShake: true,
    parallaxSpeed: 1.0,
    themeId: 'meadow',
    dayNightCycle: false,
    shockwavesEnabled: true,
  },
};

export const INITIAL_LEADERBOARD: LeaderboardEntry[] = [
  { id: '1', playerName: 'SkyMaster', score: 48, coins: 140, birdId: 'phoenix', date: '2026-08-30', themeId: 'twilight' },
  { id: '2', playerName: 'NeonWing', score: 35, coins: 95, birdId: 'cyber', date: '2026-08-31', themeId: 'cyberpunk' },
  { id: '3', playerName: 'AegisShield', score: 28, coins: 70, birdId: 'guardian', date: '2026-08-31', themeId: 'meadow' },
  { id: '4', playerName: 'Nocturnal', score: 19, coins: 45, birdId: 'shadow', date: '2026-09-01', themeId: 'night' },
  { id: '5', playerName: 'CosmicVoyager', score: 12, coins: 30, birdId: 'pip', date: '2026-09-01', themeId: 'space' },
];

export function getStoredStats(): PlayerStats {
  try {
    const raw = localStorage.getItem(STATS_KEY);
    if (!raw) return DEFAULT_STATS;
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_STATS,
      ...parsed,
      totalFlaps: parsed.totalFlaps ?? 0,
      completedQuestsCount: parsed.completedQuestsCount ?? 0,
    };
  } catch (err) {
    console.error('Failed to load player stats', err);
    return DEFAULT_STATS;
  }
}

export function saveStoredStats(stats: PlayerStats): void {
  try {
    localStorage.setItem(STATS_KEY, JSON.stringify(stats));
  } catch (err) {
    console.error('Failed to save stats', err);
  }
}

export function getStoredSettings(): GameSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_SETTINGS,
      ...parsed,
      graphics: {
        ...DEFAULT_SETTINGS.graphics,
        ...(parsed.graphics || {}),
      },
      sound: {
        ...DEFAULT_SETTINGS.sound,
        ...(parsed.sound || {}),
      },
    };
  } catch (err) {
    console.error('Failed to load settings', err);
    return DEFAULT_SETTINGS;
  }
}

export function saveStoredSettings(settings: GameSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (err) {
    console.error('Failed to save settings', err);
  }
}

export function getStoredLeaderboard(): LeaderboardEntry[] {
  try {
    const raw = localStorage.getItem(LEADERBOARD_KEY);
    if (!raw) return INITIAL_LEADERBOARD;
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to load leaderboard', err);
    return INITIAL_LEADERBOARD;
  }
}

export function saveStoredLeaderboard(entries: LeaderboardEntry[]): void {
  try {
    localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(entries));
  } catch (err) {
    console.error('Failed to save leaderboard', err);
  }
}

export function addLeaderboardScore(entry: Omit<LeaderboardEntry, 'id'>): LeaderboardEntry[] {
  const current = getStoredLeaderboard();
  const newEntry: LeaderboardEntry = {
    ...entry,
    id: `entry_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
  };

  const updated = [...current, newEntry]
    .sort((a, b) => b.score - a.score || b.coins - a.coins)
    .slice(0, 50); // Top 50

  saveStoredLeaderboard(updated);
  return updated;
}
