import { DailyQuest } from '../types/game';
import { BIRDS } from '../constants/birds';

const QUESTS_STORAGE_KEY = 'flappy_deluxe_daily_quests_v1';
const QUESTS_DATE_KEY = 'flappy_deluxe_quests_date_v1';

// Seeded pseudorandom for deterministic daily quest selection
function pseudoRandom(seed: number): number {
  const x = Math.sin(seed++) * 10000;
  return x - Math.floor(x);
}

export function generateDailyQuests(dateStr: string): DailyQuest[] {
  // Convert date string YYYY-MM-DD into a numerical seed
  const numSeed = dateStr.split('-').reduce((acc, part) => acc * 31 + parseInt(part, 10), 42);

  // Pool of candidate quests
  const candidateTemplates: Array<(seed: number) => DailyQuest> = [
    (s) => {
      const targets = [15, 25, 40, 50];
      const target = targets[Math.floor(pseudoRandom(s) * targets.length)];
      return {
        id: `pipes_${target}`,
        type: 'PASS_PIPES',
        title: 'Pipe Navigator',
        description: `Fly through a total of ${target} pipes across your runs`,
        target,
        progress: 0,
        rewardCoins: target * 4,
        completed: false,
        claimed: false,
        icon: 'Milestone',
      };
    },
    (s) => {
      const targets = [30, 60, 100, 150];
      const target = targets[Math.floor(pseudoRandom(s + 1) * targets.length)];
      return {
        id: `coins_${target}`,
        type: 'COLLECT_COINS',
        title: 'Treasure Seeker',
        description: `Collect ${target} total coins floating between obstacles`,
        target,
        progress: 0,
        rewardCoins: Math.round(target * 1.5),
        completed: false,
        claimed: false,
        icon: 'Coins',
      };
    },
    (s) => {
      const targets = [3, 5, 8];
      const target = targets[Math.floor(pseudoRandom(s + 2) * targets.length)];
      return {
        id: `runs_${target}`,
        type: 'PLAY_RUNS',
        title: 'Determined Aviator',
        description: `Complete ${target} flight expeditions today`,
        target,
        progress: 0,
        rewardCoins: target * 25,
        completed: false,
        claimed: false,
        icon: 'PlaneTakeoff',
      };
    },
    (s) => {
      const targets = [60, 120, 200];
      const target = targets[Math.floor(pseudoRandom(s + 3) * targets.length)];
      return {
        id: `flaps_${target}`,
        type: 'FLAP_WINGS',
        title: 'Wing Mastery',
        description: `Flap your wings ${target} times in total flight practice`,
        target,
        progress: 0,
        rewardCoins: Math.round(target * 0.75),
        completed: false,
        claimed: false,
        icon: 'Feather',
      };
    },
    (s) => {
      const targets = [10, 15, 20, 25];
      const target = targets[Math.floor(pseudoRandom(s + 4) * targets.length)];
      return {
        id: `single_score_${target}`,
        type: 'SCORE_SINGLE_RUN',
        title: 'Ace Pilot',
        description: `Reach a score of ${target} or higher in a single single run`,
        target,
        progress: 0,
        rewardCoins: target * 6,
        completed: false,
        claimed: false,
        icon: 'Trophy',
      };
    },
    (s) => {
      const randomBird = BIRDS[Math.floor(pseudoRandom(s + 5) * BIRDS.length)];
      const target = 10;
      return {
        id: `bird_${randomBird.id}_${target}`,
        type: 'SURVIVE_PIPES_WITH_BIRD',
        title: `${randomBird.name}'s Journey`,
        description: `Pass ${target} pipes while flying as ${randomBird.name}`,
        target,
        progress: 0,
        rewardCoins: 80,
        completed: false,
        claimed: false,
        icon: 'Bird',
        targetBirdId: randomBird.id,
      };
    },
  ];

  // Pick 3 distinct quests
  const quests: DailyQuest[] = [];
  const pickedIndices = new Set<number>();

  for (let i = 0; i < candidateTemplates.length && quests.length < 3; i++) {
    const idx = Math.floor(pseudoRandom(numSeed + i * 17) * candidateTemplates.length);
    if (!pickedIndices.has(idx)) {
      pickedIndices.add(idx);
      quests.push(candidateTemplates[idx](numSeed + i * 7));
    }
  }

  // Fallback if less than 3
  while (quests.length < 3) {
    const fallbackIdx = quests.length;
    quests.push(candidateTemplates[fallbackIdx](numSeed + fallbackIdx));
  }

  return quests;
}

export function getTodayDateString(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

export function getStoredQuests(): DailyQuest[] {
  try {
    const today = getTodayDateString();
    const storedDate = localStorage.getItem(QUESTS_DATE_KEY);
    const storedData = localStorage.getItem(QUESTS_STORAGE_KEY);

    if (storedDate === today && storedData) {
      return JSON.parse(storedData) as DailyQuest[];
    }

    // New day or first time, generate fresh
    const fresh = generateDailyQuests(today);
    localStorage.setItem(QUESTS_DATE_KEY, today);
    localStorage.setItem(QUESTS_STORAGE_KEY, JSON.stringify(fresh));
    return fresh;
  } catch (err) {
    console.error('Failed to load daily quests', err);
    return generateDailyQuests(getTodayDateString());
  }
}

export function saveStoredQuests(quests: DailyQuest[]): void {
  try {
    localStorage.setItem(QUESTS_STORAGE_KEY, JSON.stringify(quests));
    localStorage.setItem(QUESTS_DATE_KEY, getTodayDateString());
  } catch (err) {
    console.error('Failed to save daily quests', err);
  }
}

export interface FlightRunRecord {
  score: number;
  coins: number;
  pipesPassed: number;
  flaps: number;
  birdId: string;
}

/**
 * Updates quests with stats from the completed or ongoing flight
 */
export function updateQuestsWithRun(
  currentQuests: DailyQuest[],
  run: FlightRunRecord
): { updatedQuests: DailyQuest[]; newlyCompleted: DailyQuest[] } {
  const newlyCompleted: DailyQuest[] = [];

  const updatedQuests = currentQuests.map((quest) => {
    if (quest.completed) return quest;

    let delta = 0;
    let absoluteSet: number | null = null;

    switch (quest.type) {
      case 'PASS_PIPES':
        delta = run.pipesPassed;
        break;
      case 'COLLECT_COINS':
        delta = run.coins;
        break;
      case 'PLAY_RUNS':
        delta = 1;
        break;
      case 'FLAP_WINGS':
        delta = run.flaps;
        break;
      case 'SCORE_SINGLE_RUN':
        absoluteSet = Math.max(quest.progress, run.score);
        break;
      case 'SURVIVE_PIPES_WITH_BIRD':
        if (quest.targetBirdId === run.birdId) {
          delta = run.pipesPassed;
        }
        break;
      default:
        break;
    }

    const newProgress = absoluteSet !== null 
      ? Math.min(quest.target, absoluteSet)
      : Math.min(quest.target, quest.progress + delta);

    const isNowCompleted = newProgress >= quest.target;
    if (isNowCompleted && !quest.completed) {
      newlyCompleted.push({
        ...quest,
        progress: newProgress,
        completed: true,
      });
    }

    return {
      ...quest,
      progress: newProgress,
      completed: isNowCompleted,
    };
  });

  return { updatedQuests, newlyCompleted };
}
