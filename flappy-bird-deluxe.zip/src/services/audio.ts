import { SoundSettings } from '../types/game';

class RetroSoundEngine {
  private ctx: AudioContext | null = null;
  private settings: SoundSettings = {
    masterVolume: 0.85,
    sfxVolume: 0.9,
    bgmVolume: 0.4,
    sfxEnabled: true,
    bgmEnabled: false, // Default BGM to off for authentic classic Flappy arcade experience
  };

  private isBgmPlaying = false;
  private bgmIntervalId: number | null = null;
  private bgmNoteIndex = 0;

  // Melody notes frequencies (Hz) for optional upbeat 8-bit arcade loop
  private melodyNotes: number[] = [
    330, 392, 440, 523, 440, 392, 330, 262,
    294, 349, 392, 440, 392, 349, 294, 330,
    330, 392, 523, 659, 587, 523, 440, 392,
    440, 494, 523, 587, 659, 523, 440, 330,
  ];

  constructor() {
    // AudioContext will be initialized on first user interaction
  }

  private initContext(): AudioContext | null {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public applySettings(settings: SoundSettings) {
    this.settings = { ...settings };
    if (!this.settings.bgmEnabled && this.isBgmPlaying) {
      this.stopBGM();
    }
  }

  // --- AUTHENTIC FLAPPY BIRD SFX ---

  /**
   * Classic Wing Flap (Crisp airy pitch sweep upward)
   */
  public playFlap() {
    if (!this.settings.sfxEnabled) return;
    const ctx = this.initContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      // Rapid swoop from 380Hz to 680Hz
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(360, now);
      osc.frequency.exponentialRampToValueAtTime(740, now + 0.08);

      const vol = this.settings.masterVolume * this.settings.sfxVolume * 0.4;
      gain.gain.setValueAtTime(vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.09);
    } catch {
      // Ignore audio errors during rapid interaction
    }
  }

  /**
   * Classic Point Score (Iconic bright double-bell chime when clearing a pipe)
   */
  public playScore() {
    if (!this.settings.sfxEnabled) return;
    const ctx = this.initContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      // High crisp chime (D6 ~ 1174Hz to G6 ~ 1568Hz)
      osc.frequency.setValueAtTime(1046.5, now); // C6
      osc.frequency.setValueAtTime(1318.5, now + 0.07); // E6

      const vol = this.settings.masterVolume * this.settings.sfxVolume * 0.5;
      gain.gain.setValueAtTime(vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.26);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.26);
    } catch {
      // Ignore
    }
  }

  /**
   * Coin Collect (Bright energetic double pickup chime)
   */
  public playCoin() {
    if (!this.settings.sfxEnabled) return;
    const ctx = this.initContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.type = 'square';
      osc2.type = 'sine';

      osc1.frequency.setValueAtTime(987.77, now); // B5
      osc1.frequency.setValueAtTime(1318.51, now + 0.06); // E6

      osc2.frequency.setValueAtTime(987.77, now);
      osc2.frequency.setValueAtTime(1318.51, now + 0.06);

      const vol = this.settings.masterVolume * this.settings.sfxVolume * 0.25;
      gain.gain.setValueAtTime(vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.22);
      osc2.stop(now + 0.22);
    } catch {
      // Ignore
    }
  }

  /**
   * Pipe / Ground Collision (Crisp arcade punch thud)
   */
  public playHit() {
    if (!this.settings.sfxEnabled) return;
    const ctx = this.initContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(260, now);
      osc.frequency.exponentialRampToValueAtTime(40, now + 0.18);

      const vol = this.settings.masterVolume * this.settings.sfxVolume * 0.7;
      gain.gain.setValueAtTime(vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.18);
    } catch {
      // Ignore
    }
  }

  /**
   * Falling Down / Game Over (Classic falling whistle drop)
   */
  public playGameOver() {
    if (!this.settings.sfxEnabled) return;
    const ctx = this.initContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(460, now);
      osc.frequency.exponentialRampToValueAtTime(110, now + 0.35);

      const vol = this.settings.masterVolume * this.settings.sfxVolume * 0.45;
      gain.gain.setValueAtTime(vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.35);
    } catch {
      // Ignore
    }
  }

  /**
   * Shield Fracture / Energy Break
   */
  public playShieldBreak() {
    if (!this.settings.sfxEnabled) return;
    const ctx = this.initContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(900, now);
      osc.frequency.exponentialRampToValueAtTime(160, now + 0.3);

      const vol = this.settings.masterVolume * this.settings.sfxVolume * 0.55;
      gain.gain.setValueAtTime(vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.3);
    } catch {
      // Ignore
    }
  }

  /**
   * Quest Completed Fanfare
   */
  public playQuestComplete() {
    if (!this.settings.sfxEnabled) return;
    const ctx = this.initContext();
    if (!ctx) return;

    try {
      const chord = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
      chord.forEach((freq, idx) => {
        if (!ctx) return;
        const now = ctx.currentTime + idx * 0.08;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now);

        const vol = this.settings.masterVolume * this.settings.sfxVolume * 0.4;
        gain.gain.setValueAtTime(vol, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + (idx === chord.length - 1 ? 0.4 : 0.18));

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now);
        osc.stop(now + (idx === chord.length - 1 ? 0.4 : 0.18));
      });
    } catch {
      // Ignore
    }
  }

  /**
   * Atmospheric Event Alert Chime
   */
  public playEventAlert() {
    if (!this.settings.sfxEnabled) return;
    const ctx = this.initContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, now); // D5
      osc.frequency.setValueAtTime(880.0, now + 0.1); // A5
      osc.frequency.setValueAtTime(1174.66, now + 0.2); // D6

      const vol = this.settings.masterVolume * this.settings.sfxVolume * 0.35;
      gain.gain.setValueAtTime(vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.4);
    } catch {
      // Ignore
    }
  }

  /**
   * Button Click
   */
  public playClick() {
    if (!this.settings.sfxEnabled) return;
    const ctx = this.initContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(750, now);
      osc.frequency.exponentialRampToValueAtTime(420, now + 0.035);

      const vol = this.settings.masterVolume * this.settings.sfxVolume * 0.22;
      gain.gain.setValueAtTime(vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.035);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.035);
    } catch {
      // Ignore
    }
  }

  /**
   * Unlock / Purchase Fanfare
   */
  public playUnlock() {
    if (!this.settings.sfxEnabled) return;
    const ctx = this.initContext();
    if (!ctx) return;

    try {
      const chords = [523.25, 659.25, 783.99, 1046.50];
      const step = 0.07;

      chords.forEach((freq, idx) => {
        if (!ctx) return;
        const now = ctx.currentTime + idx * step;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now);

        const vol = this.settings.masterVolume * this.settings.sfxVolume * 0.38;
        gain.gain.setValueAtTime(vol, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now);
        osc.stop(now + 0.28);
      });
    } catch {
      // Ignore
    }
  }

  public playBuy() {
    this.playUnlock();
  }

  // --- BACKGROUND MUSIC LOOP (Optional) ---

  public startBGM() {
    if (!this.settings.bgmEnabled || this.isBgmPlaying) return;
    const ctx = this.initContext();
    if (!ctx) return;

    this.isBgmPlaying = true;
    this.bgmNoteIndex = 0;

    const tempoMs = 210;

    this.bgmIntervalId = window.setInterval(() => {
      if (!this.settings.bgmEnabled || !this.ctx) {
        this.stopBGM();
        return;
      }

      const noteFreq = this.melodyNotes[this.bgmNoteIndex];
      this.bgmNoteIndex = (this.bgmNoteIndex + 1) % this.melodyNotes.length;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'square';
      osc.frequency.setValueAtTime(noteFreq, now);

      const vol = this.settings.masterVolume * this.settings.bgmVolume * 0.04;
      gain.gain.setValueAtTime(vol, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.17);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.17);
    }, tempoMs);
  }

  public stopBGM() {
    this.isBgmPlaying = false;
    if (this.bgmIntervalId !== null) {
      clearInterval(this.bgmIntervalId);
      this.bgmIntervalId = null;
    }
  }
}

export const sound = new RetroSoundEngine();
