export type GameState = 
  | 'MENU' 
  | 'PLAYING' 
  | 'PAUSED' 
  | 'GAMEOVER' 
  | 'SHOP' 
  | 'SETTINGS' 
  | 'LEADERBOARD' 
  | 'HOWTO'
  | 'QUESTS'
  | 'EVENTS';

export type BirdAbility = 
  | 'none' 
  | 'glide' 
  | 'double_coins' 
  | 'shield' 
  | 'smaller_hitbox' 
  | 'coin_magnet' 
  | 'floaty_wings' 
  | 'celestial_mastery';

export type Rarity = 'Common' | 'Rare' | 'Epic' | 'Legendary' | 'Mythic';

export interface BirdConfig {
  id: string;
  name: string;
  title: string;
  description: string;
  price: number;
  rarity: Rarity;
  ability: BirdAbility;
  abilityName: string;
  abilityDesc: string;
  
  // Gameplay physics modifiers
  gravityMultiplier: number;
  flapStrength: number;
  hitboxRadius: number; // base ~12
  coinMultiplier: number;
  magnetRadius: number; // 0 for none, >0 in px
  hasShield: boolean;
  
  // Visuals
  primaryColor: string;
  secondaryColor: string;
  bellyColor: string;
  wingColor: string;
  beakColor: string;
  eyeColor: string;
  trailType: 'feathers' | 'fire' | 'electric' | 'stars' | 'bubbles' | 'smoke' | 'shadow' | 'rainbow' | 'cosmic';
  glowColor?: string;
}

export interface Pipe {
  x: number;
  topHeight: number;
  bottomHeight: number;
  width: number;
  gap: number;
  passed: boolean;
  coinSpawned: boolean;
}

export interface CoinItem {
  id: number;
  x: number;
  y: number;
  value: number; // 1, 2, 5
  collected: boolean;
  animOffset: number;
  scale: number;
}

export interface Shockwave {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  color: string;
  alpha: number;
  lineWidth: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
  rotation?: number;
  vRot?: number;
  shape?: 'circle' | 'star' | 'spark' | 'feather' | 'smoke' | 'confetti' | 'ring' | 'heart';
}

export interface FloatingText {
  id: number;
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  scale: number;
  vy: number;
}

export interface ThemeConfig {
  id: string;
  name: string;
  skyTop: string;
  skyBottom: string;
  mountainsColor: string;
  cityColor: string;
  treesColor: string;
  groundTop: string;
  groundBody: string;
  pipeColor: string;
  pipeHighlight: string;
  pipeRim: string;
  pipeDark: string;
  cloudAlpha: number;
  ambientLight: string;
  weather?: 'none' | 'stars' | 'fireflies' | 'petals' | 'cyberGrid' | 'aurora' | 'snow';
}

export interface SoundSettings {
  masterVolume: number;
  sfxVolume: number;
  bgmVolume: number;
  sfxEnabled: boolean;
  bgmEnabled: boolean;
}

export interface GraphicsSettings {
  particlesEnabled: boolean;
  screenShake: boolean;
  parallaxSpeed: number;
  themeId: string;
  dayNightCycle: boolean;
  shockwavesEnabled: boolean;
}

export interface GameSettings {
  sound: SoundSettings;
  graphics: GraphicsSettings;
  playerName: string;
}

export interface LeaderboardEntry {
  id: string;
  playerName: string;
  score: number;
  coins: number;
  birdId: string;
  date: string;
  themeId: string;
}

export interface PlayerStats {
  highScore: number;
  totalCoins: number;
  gamesPlayed: number;
  totalPipesPassed: number;
  totalCoinsCollected: number;
  totalFlaps: number;
  unlockedBirds: string[];
  selectedBirdId: string;
  completedQuestsCount: number;
}

// DAILY QUEST TYPES
export type QuestType = 
  | 'PASS_PIPES' 
  | 'COLLECT_COINS' 
  | 'PLAY_RUNS' 
  | 'FLAP_WINGS' 
  | 'SCORE_SINGLE_RUN'
  | 'SURVIVE_PIPES_WITH_BIRD';

export interface DailyQuest {
  id: string;
  type: QuestType;
  title: string;
  description: string;
  target: number;
  progress: number;
  rewardCoins: number;
  completed: boolean;
  claimed: boolean;
  icon: string;
  targetBirdId?: string;
}

// DYNAMIC EVENT TYPES
export type DynamicEventType = 
  | 'GOLD_RUSH' 
  | 'GRAVITY_SURGE' 
  | 'NEBULA_DRIFT' 
  | 'DOUBLE_SCORE' 
  | 'SHIELD_CARNIVAL' 
  | 'TURBO_SPEED';

export interface DynamicEvent {
  id: DynamicEventType;
  name: string;
  badge: string;
  tagline: string;
  description: string;
  icon: string;
  bannerColor: string;
  glowColor: string;
  bgTint?: string;
  
  // Modifiers applied during gameplay
  gravityMultiplierMod: number; // e.g. 0.7 for floaty
  speedMultiplierMod: number; // e.g. 1.25 for turbo
  coinRateMod: number; // 2x or 3x
  allGoldCoins: boolean;
  doubleScoreMod: boolean;
  freeShieldOnStart: boolean;
  
  activeMinutesDuration: number;
}
