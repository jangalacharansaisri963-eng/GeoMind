import React from 'react';
import { GameSettings } from '../types/game';
import { THEMES } from '../constants/themes';
import { sound } from '../services/audio';
import { X, Volume2, VolumeX, Music, Sparkles, Activity, Palette, RotateCcw } from 'lucide-react';

interface SettingsModalProps {
  settings: GameSettings;
  onUpdateSettings: (newSettings: GameSettings) => void;
  onResetData: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onResetData,
  onClose,
}) => {
  const handleSoundChange = (field: keyof GameSettings['sound'], value: number | boolean) => {
    const updated = {
      ...settings,
      sound: {
        ...settings.sound,
        [field]: value,
      },
    };
    onUpdateSettings(updated);
    sound.applySettings(updated.sound);
    if (field === 'sfxEnabled' && value) {
      sound.playClick();
    }
  };

  const handleGraphicsChange = (field: keyof GameSettings['graphics'], value: string | boolean | number) => {
    sound.playClick();
    const updated = {
      ...settings,
      graphics: {
        ...settings.graphics,
        [field]: value,
      },
    };
    onUpdateSettings(updated);
  };

  const confirmReset = () => {
    if (window.confirm('Are you sure you want to reset all game data, unlocked birds, and high scores?')) {
      onResetData();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-slate-900 border-2 border-slate-700/90 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <Volume2 className="w-6 h-6 text-indigo-400" />
            <div>
              <h2 className="text-xl font-bold text-slate-100 font-['Fredoka']">GAME SETTINGS</h2>
              <p className="text-xs text-slate-400">Audio, background themes & visual effects</p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 flex flex-col gap-5">
          {/* SECTION 1: AUDIO SETTINGS */}
          <div className="flex flex-col gap-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
              <Volume2 className="w-3.5 h-3.5" />
              <span>Audio & Synth Controls</span>
            </h3>

            {/* Sound FX Toggle & Volume */}
            <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-2xl flex flex-col gap-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {settings.sound.sfxEnabled ? (
                    <Volume2 className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <VolumeX className="w-4 h-4 text-slate-500" />
                  )}
                  <span className="text-sm font-semibold text-slate-200">Sound Effects (SFX)</span>
                </div>

                {/* Toggle switch */}
                <button
                  onClick={() => handleSoundChange('sfxEnabled', !settings.sound.sfxEnabled)}
                  className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                    settings.sound.sfxEnabled ? 'bg-emerald-500 justify-end' : 'bg-slate-700 justify-start'
                  }`}
                >
                  <div className="w-4 h-4 rounded-full bg-white shadow-sm" />
                </button>
              </div>

              {settings.sound.sfxEnabled && (
                <div className="flex items-center gap-3 pt-1">
                  <span className="text-[11px] text-slate-400 font-medium">SFX Vol</span>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={settings.sound.sfxVolume}
                    onChange={(e) => handleSoundChange('sfxVolume', parseFloat(e.target.value))}
                    className="flex-1 accent-emerald-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                  />
                  <span className="text-[11px] font-mono text-slate-400 w-8 text-right">
                    {Math.round(settings.sound.sfxVolume * 100)}%
                  </span>
                </div>
              )}
            </div>

            {/* Chiptune BGM Music Toggle & Volume */}
            <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-2xl flex flex-col gap-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Music className={`w-4 h-4 ${settings.sound.bgmEnabled ? 'text-indigo-400' : 'text-slate-500'}`} />
                  <span className="text-sm font-semibold text-slate-200">Retro Chiptune BGM</span>
                </div>

                <button
                  onClick={() => handleSoundChange('bgmEnabled', !settings.sound.bgmEnabled)}
                  className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                    settings.sound.bgmEnabled ? 'bg-indigo-500 justify-end' : 'bg-slate-700 justify-start'
                  }`}
                >
                  <div className="w-4 h-4 rounded-full bg-white shadow-sm" />
                </button>
              </div>

              {settings.sound.bgmEnabled && (
                <div className="flex items-center gap-3 pt-1">
                  <span className="text-[11px] text-slate-400 font-medium">BGM Vol</span>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={settings.sound.bgmVolume}
                    onChange={(e) => handleSoundChange('bgmVolume', parseFloat(e.target.value))}
                    className="flex-1 accent-indigo-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                  />
                  <span className="text-[11px] font-mono text-slate-400 w-8 text-right">
                    {Math.round(settings.sound.bgmVolume * 100)}%
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* SECTION 2: PARALLAX BACKGROUND THEMES */}
          <div className="flex flex-col gap-2.5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5" />
              <span>Animated Parallax Theme</span>
            </h3>

            <div className="grid grid-cols-2 gap-2">
              {THEMES.map((theme) => {
                const isSelected = settings.graphics.themeId === theme.id;
                return (
                  <button
                    key={theme.id}
                    onClick={() => handleGraphicsChange('themeId', theme.id)}
                    className={`p-2.5 rounded-xl border text-left flex flex-col gap-1 transition-all ${
                      isSelected
                        ? 'border-amber-400 bg-slate-800 shadow-md ring-1 ring-amber-400'
                        : 'border-slate-800 bg-slate-950/40 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      {/* Theme color swatch */}
                      <div
                        className="w-4 h-4 rounded-full border border-white/20 shrink-0"
                        style={{
                          background: `linear-gradient(135deg, ${theme.skyTop}, ${theme.groundTop})`,
                        }}
                      />
                      <span className="text-xs font-bold text-slate-200">{theme.name}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* SECTION 3: VISUAL EFFECTS */}
          <div className="flex flex-col gap-2.5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Visual Polish & Particles</span>
            </h3>

            <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-2xl flex flex-col gap-3">
              {/* Screen Shake */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-semibold text-slate-200">Impact Screen Shake</span>
                </div>
                <button
                  onClick={() => handleGraphicsChange('screenShake', !settings.graphics.screenShake)}
                  className={`w-10 h-5 flex items-center rounded-full p-0.5 transition-colors ${
                    settings.graphics.screenShake ? 'bg-cyan-500 justify-end' : 'bg-slate-700 justify-start'
                  }`}
                >
                  <div className="w-4 h-4 rounded-full bg-white shadow-sm" />
                </button>
              </div>

              {/* Particle Trails */}
              <div className="flex items-center justify-between border-t border-slate-800/80 pt-2.5">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-semibold text-slate-200">Bird Trails & Coin Bursts</span>
                </div>
                <button
                  onClick={() => handleGraphicsChange('particlesEnabled', !settings.graphics.particlesEnabled)}
                  className={`w-10 h-5 flex items-center rounded-full p-0.5 transition-colors ${
                    settings.graphics.particlesEnabled ? 'bg-amber-500 justify-end' : 'bg-slate-700 justify-start'
                  }`}
                >
                  <div className="w-4 h-4 rounded-full bg-white shadow-sm" />
                </button>
              </div>
            </div>
          </div>

          {/* SECTION 4: RESET DATA */}
          <div className="pt-2 border-t border-slate-800">
            <button
              onClick={confirmReset}
              className="w-full py-2.5 px-4 rounded-xl bg-rose-950/40 border border-rose-600/40 hover:bg-rose-900/40 text-rose-300 font-bold text-xs flex items-center justify-center gap-2 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Game Data & High Scores</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
