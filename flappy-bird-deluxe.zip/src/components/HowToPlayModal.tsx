import React from 'react';
import { sound } from '../services/audio';
import { X, Shield, Magnet, Zap, Trophy, Coins, Compass } from 'lucide-react';

interface HowToPlayModalProps {
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-slate-900 border-2 border-slate-700/90 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <Compass className="w-6 h-6 text-sky-400" />
            <div>
              <h2 className="text-xl font-bold text-slate-100 font-['Fredoka']">HOW TO PLAY</h2>
              <p className="text-xs text-slate-400">Master the skies & arcade mechanics</p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 flex flex-col gap-4">
          {/* Rule 1: Flight */}
          <div className="p-3.5 bg-slate-950/40 border border-slate-800 rounded-2xl flex items-start gap-3">
            <div className="text-2xl p-2 bg-sky-500/20 rounded-xl">🕊️</div>
            <div>
              <h3 className="font-bold text-sm text-slate-100 font-['Fredoka']">Flap & Navigate</h3>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                Click, tap, or press <span className="text-amber-400 font-semibold">SPACE</span> to flap upward. Carefully time your flaps to glide smoothly through pipe gaps without colliding with obstacles or the ground.
              </p>
            </div>
          </div>

          {/* Rule 2: Coins & Currency */}
          <div className="p-3.5 bg-slate-950/40 border border-slate-800 rounded-2xl flex items-start gap-3">
            <div className="text-2xl p-2 bg-amber-500/20 rounded-xl">🪙</div>
            <div>
              <h3 className="font-bold text-sm text-slate-100 font-['Fredoka']">Collect Coins</h3>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                Grab shiny bronze (+1), silver (+2), and gold (+5★) coins suspended between pipes. Spend your coins in the Aviary Shop to unlock higher rarity birds!
              </p>
            </div>
          </div>

          {/* Rule 3: Bird Special Abilities */}
          <div className="p-3.5 bg-slate-950/40 border border-slate-800 rounded-2xl flex flex-col gap-2.5">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-cyan-400" />
              <h3 className="font-bold text-sm text-slate-100 font-['Fredoka']">Bird Perks & Abilities</h3>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-300">
              <div className="flex items-center gap-1.5 bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                <Shield className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span><b className="text-emerald-300">Shield:</b> 1 free hit forgiveness</span>
              </div>
              <div className="flex items-center gap-1.5 bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                <Magnet className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                <span><b className="text-sky-300">Magnet:</b> Pulls nearby coins</span>
              </div>
              <div className="flex items-center gap-1.5 bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                <Coins className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span><b className="text-amber-300">2x Coins:</b> Double coin multiplier</span>
              </div>
              <div className="flex items-center gap-1.5 bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                <Trophy className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <span><b className="text-purple-300">Ghost:</b> 20% smaller hitbox</span>
              </div>
            </div>
          </div>

          {/* Rule 4: Medal Ranks */}
          <div className="p-3.5 bg-slate-950/40 border border-slate-800 rounded-2xl flex items-start gap-3">
            <div className="text-2xl p-2 bg-indigo-500/20 rounded-xl">🏅</div>
            <div>
              <h3 className="font-bold text-sm text-slate-100 font-['Fredoka']">Score Medals</h3>
              <div className="flex items-center gap-3 mt-1.5 text-xs text-slate-300">
                <span>🥉 10+</span>
                <span>🥈 25+</span>
                <span>🥇 50+</span>
                <span>💎 75+</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950/70 border-t border-slate-800">
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-full py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm uppercase font-['Fredoka'] tracking-wide transition-all shadow-md active:scale-95"
          >
            GOT IT, LET'S FLY!
          </button>
        </div>
      </div>
    </div>
  );
};
