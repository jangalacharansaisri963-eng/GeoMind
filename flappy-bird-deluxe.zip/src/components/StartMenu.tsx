import { motion } from 'motion/react';
import { Play, ShoppingBag, Trophy, Settings, HelpCircle, Gift, Zap, Sparkles, ChevronLeft, ChevronRight } from 'lucide-react';
import { PlayerStats, BirdConfig, DynamicEvent } from '../types/game';
import { BIRDS } from '../constants/birds';
import { sound } from '../services/audio';

interface StartMenuProps {
  stats: PlayerStats;
  selectedBird: BirdConfig;
  activeEvent: DynamicEvent | null;
  unclaimedQuestsCount: number;
  onStartGame: () => void;
  onOpenShop: () => void;
  onOpenLeaderboard: () => void;
  onOpenSettings: () => void;
  onOpenHowTo: () => void;
  onOpenQuests: () => void;
  onOpenEvents: () => void;
  onSelectBird: (birdId: string) => void;
}

export function StartMenu({
  stats,
  selectedBird,
  activeEvent,
  unclaimedQuestsCount,
  onStartGame,
  onOpenShop,
  onOpenLeaderboard,
  onOpenSettings,
  onOpenHowTo,
  onOpenQuests,
  onOpenEvents,
  onSelectBird,
}: StartMenuProps) {
  const unlockedBirdsList = BIRDS.filter((b) => stats.unlockedBirds.includes(b.id));
  const currentIdx = unlockedBirdsList.findIndex((b) => b.id === selectedBird.id);

  const handlePrevBird = () => {
    sound.playClick();
    const nextIdx = (currentIdx - 1 + unlockedBirdsList.length) % unlockedBirdsList.length;
    onSelectBird(unlockedBirdsList[nextIdx].id);
  };

  const handleNextBird = () => {
    sound.playClick();
    const nextIdx = (currentIdx + 1) % unlockedBirdsList.length;
    onSelectBird(unlockedBirdsList[nextIdx].id);
  };

  return (
    <div className="absolute inset-0 flex flex-col justify-between p-4 sm:p-6 pointer-events-auto bg-slate-950/20 backdrop-blur-[1px] select-none">
      {/* Top Header Bar */}
      <div className="flex items-center justify-between w-full pt-1">
        {/* Bank Coins Pill */}
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => {
            sound.playClick();
            onOpenShop();
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900/90 border border-amber-500/40 rounded-full shadow-lg cursor-pointer hover:border-amber-400 transition-colors"
        >
          <span className="text-sm">🪙</span>
          <span className="font-extrabold text-amber-300 text-sm tracking-wide">{stats.totalCoins}</span>
        </motion.div>

        {/* Action icons right (Quests, Events, Leaderboard, Settings) */}
        <div className="flex items-center gap-1.5">
          {/* Daily Quests Button */}
          <motion.button
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.92 }}
            onClick={() => {
              sound.playClick();
              onOpenQuests();
            }}
            className="relative p-2 rounded-full bg-slate-900/90 border border-amber-500/40 text-amber-400 hover:text-amber-300 hover:border-amber-400 shadow-md transition-colors cursor-pointer"
            title="Daily Quests"
          >
            <Gift className="w-4 h-4" />
            {unclaimedQuestsCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] font-black text-white animate-bounce">
                {unclaimedQuestsCount}
              </span>
            )}
          </motion.button>

          {/* Dynamic Events Button */}
          <motion.button
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.92 }}
            onClick={() => {
              sound.playClick();
              onOpenEvents();
            }}
            className="relative p-2 rounded-full bg-slate-900/90 border border-cyan-500/40 text-cyan-400 hover:text-cyan-300 hover:border-cyan-400 shadow-md transition-colors cursor-pointer"
            title="Active Event"
          >
            <Zap className="w-4 h-4" />
            <span className="absolute -top-0.5 -right-0.5 flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
            </span>
          </motion.button>

          {/* Leaderboard Button */}
          <motion.button
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.92 }}
            onClick={() => {
              sound.playClick();
              onOpenLeaderboard();
            }}
            className="p-2 rounded-full bg-slate-900/90 border border-slate-700 text-slate-200 hover:text-yellow-400 hover:border-yellow-500/40 shadow-md transition-colors cursor-pointer"
            title="Leaderboard"
          >
            <Trophy className="w-4 h-4" />
          </motion.button>

          {/* Settings Button */}
          <motion.button
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.92 }}
            onClick={() => {
              sound.playClick();
              onOpenSettings();
            }}
            className="p-2 rounded-full bg-slate-900/90 border border-slate-700 text-slate-200 hover:text-white shadow-md transition-colors cursor-pointer"
            title="Settings"
          >
            <Settings className="w-4 h-4" />
          </motion.button>
        </div>
      </div>

      {/* Main Center Section */}
      <div className="flex flex-col items-center justify-center my-auto text-center space-y-4">
        {/* Iconic Flappy Bird Title */}
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.35 }}
          className="flex flex-col items-center"
        >
          <div className="flex items-center gap-1 px-2.5 py-0.5 mb-1.5 bg-amber-500/10 border border-amber-500/30 rounded-full">
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span className="text-[10px] font-black tracking-widest text-amber-400 uppercase">
              DELUXE ARCADE
            </span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-white drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)]">
            FLAPPY <span className="text-amber-400">BIRD</span>
          </h1>
        </motion.div>

        {/* Active Event Live Pill */}
        {activeEvent && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              sound.playClick();
              onOpenEvents();
            }}
            className="px-3 py-1.5 bg-slate-900/90 border border-cyan-500/50 rounded-full shadow-lg cursor-pointer flex items-center gap-2"
          >
            <Zap className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span className="text-xs font-bold text-slate-100">{activeEvent.name}</span>
            <span className="text-[9px] font-black uppercase px-1.5 py-0.2 bg-cyan-950 text-cyan-300 rounded border border-cyan-700">
              {activeEvent.badge}
            </span>
          </motion.div>
        )}

        {/* Bird Carousel Selector */}
        <div className="flex items-center justify-center gap-3 w-full max-w-[240px]">
          {unlockedBirdsList.length > 1 && (
            <button
              onClick={handlePrevBird}
              className="p-1.5 rounded-full bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-700 transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          )}

          <div className="flex flex-col items-center">
            <div className="flex items-center gap-1.5">
              <span className="text-sm font-extrabold text-white">{selectedBird.name}</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-amber-300 font-bold border border-slate-700">
                {selectedBird.rarity}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium">{selectedBird.abilityDesc}</p>
          </div>

          {unlockedBirdsList.length > 1 && (
            <button
              onClick={handleNextBird}
              className="p-1.5 rounded-full bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-700 transition-colors cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* High Score Pill */}
        <div className="flex items-center gap-2 px-3 py-1 bg-slate-900/80 border border-slate-800 rounded-full text-xs text-slate-300">
          <span>Best:</span>
          <span className="font-extrabold text-amber-400 text-sm">{stats.highScore}</span>
        </div>
      </div>

      {/* Bottom Action Controls */}
      <div className="flex flex-col items-center w-full space-y-2.5 pb-2">
        {/* Big Classic Play Button */}
        <motion.button
          whileHover={{ scale: 1.04 }}
          whileTap={{ scale: 0.96 }}
          onClick={() => {
            sound.playClick();
            onStartGame();
          }}
          className="w-full max-w-[240px] py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-lg shadow-xl shadow-amber-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <Play className="w-5 h-5 fill-slate-950" />
          <span>PLAY</span>
        </motion.button>

        {/* Secondary Buttons Row */}
        <div className="flex items-center justify-center gap-2 w-full max-w-[240px]">
          {/* Aviary Shop */}
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              sound.playClick();
              onOpenShop();
            }}
            className="flex-1 py-2 px-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 text-xs font-bold border border-slate-700 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-amber-400" />
            <span>Aviary</span>
          </motion.button>

          {/* Daily Quests button */}
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              sound.playClick();
              onOpenQuests();
            }}
            className="flex-1 py-2 px-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 text-xs font-bold border border-slate-700 flex items-center justify-center gap-1.5 transition-colors relative cursor-pointer"
          >
            <Gift className="w-3.5 h-3.5 text-amber-400" />
            <span>Quests</span>
            {unclaimedQuestsCount > 0 && (
              <span className="w-2 h-2 rounded-full bg-rose-500 absolute top-1.5 right-1.5"></span>
            )}
          </motion.button>

          {/* How to Play */}
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              sound.playClick();
              onOpenHowTo();
            }}
            className="py-2 px-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-300 text-xs font-medium border border-slate-700 flex items-center justify-center transition-colors cursor-pointer"
            title="How to Play"
          >
            <HelpCircle className="w-3.5 h-3.5" />
          </motion.button>
        </div>
      </div>
    </div>
  );
}
