import React, { useState } from 'react';
import { LeaderboardEntry, PlayerStats } from '../types/game';
import { BIRDS } from '../constants/birds';
import { sound } from '../services/audio';
import { X, Trophy, Medal, Crown, User, Sparkles, Check, Edit2 } from 'lucide-react';

interface LeaderboardModalProps {
  entries: LeaderboardEntry[];
  stats: PlayerStats;
  playerName: string;
  onUpdatePlayerName: (newName: string) => void;
  onClose: () => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  entries,
  stats,
  playerName,
  onUpdatePlayerName,
  onClose,
}) => {
  const [filter, setFilter] = useState<'ALL' | 'MINE'>('ALL');
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState(playerName);

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    if (tempName.trim()) {
      sound.playClick();
      onUpdatePlayerName(tempName.trim().slice(0, 14));
      setIsEditingName(false);
    }
  };

  const filteredEntries = filter === 'MINE'
    ? entries.filter((e) => e.playerName.toLowerCase() === playerName.toLowerCase())
    : entries;

  const getRankMedal = (index: number) => {
    if (index === 0) {
      return (
        <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 text-slate-950 font-black flex items-center justify-center shadow-lg shadow-amber-500/30">
          <Crown className="w-4 h-4 fill-slate-950" />
        </div>
      );
    }
    if (index === 1) {
      return (
        <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-slate-400 to-slate-200 text-slate-950 font-black flex items-center justify-center shadow-lg shadow-slate-400/20">
          <Medal className="w-4 h-4 fill-slate-900" />
        </div>
      );
    }
    if (index === 2) {
      return (
        <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-700 to-amber-600 text-amber-100 font-black flex items-center justify-center shadow-lg">
          <Medal className="w-4 h-4 text-amber-100" />
        </div>
      );
    }
    return (
      <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 font-bold text-xs flex items-center justify-center border border-slate-700">
        #{index + 1}
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-slate-900 border-2 border-slate-700/90 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <Trophy className="w-6 h-6 text-amber-400" />
            <div>
              <h2 className="text-xl font-bold text-slate-100 font-['Fredoka']">HIGH SCORES</h2>
              <p className="text-xs text-slate-400">Hall of fame & arcade rankings</p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Player Profile & Name Editor Strip */}
        <div className="p-3 bg-slate-950/40 border-b border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-1">
            <div className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-300">
              <User className="w-4 h-4" />
            </div>

            {isEditingName ? (
              <form onSubmit={handleSaveName} className="flex items-center gap-1.5 flex-1">
                <input
                  type="text"
                  value={tempName}
                  onChange={(e) => setTempName(e.target.value)}
                  maxLength={14}
                  autoFocus
                  className="bg-slate-800 border border-indigo-500 rounded px-2 py-0.5 text-xs text-white outline-none w-full"
                />
                <button
                  type="submit"
                  className="p-1 rounded bg-indigo-600 text-white hover:bg-indigo-500"
                >
                  <Check className="w-3.5 h-3.5" />
                </button>
              </form>
            ) : (
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-slate-200">{playerName}</span>
                <button
                  onClick={() => setIsEditingName(true)}
                  className="text-slate-400 hover:text-indigo-400 p-0.5"
                  title="Edit Name"
                >
                  <Edit2 className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>

          {/* Quick Best Score Display */}
          <div className="flex items-center gap-1.5 bg-amber-500/10 border border-amber-500/30 rounded-full px-2.5 py-0.5 text-amber-300 font-bold text-xs">
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>Best: {stats.highScore}</span>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex p-2 gap-2 bg-slate-950/20 border-b border-slate-800">
          <button
            onClick={() => {
              sound.playClick();
              setFilter('ALL');
            }}
            className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filter === 'ALL'
                ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            GLOBAL TOP RANKS
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setFilter('MINE');
            }}
            className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filter === 'MINE'
                ? 'bg-indigo-600 text-white shadow-md font-black'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            MY RUNS
          </button>
        </div>

        {/* Leaderboard List */}
        <div className="p-3 overflow-y-auto flex-1 flex flex-col gap-2">
          {filteredEntries.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-10 text-center text-slate-400">
              <Trophy className="w-10 h-10 text-slate-600 mb-2" />
              <p className="text-sm font-semibold">No records found yet</p>
              <p className="text-xs text-slate-500">Play a game to register your high scores!</p>
            </div>
          ) : (
            filteredEntries.map((entry, idx) => {
              const birdUsed = BIRDS.find((b) => b.id === entry.birdId) || BIRDS[0];
              const isCurrentUser = entry.playerName.toLowerCase() === playerName.toLowerCase();

              return (
                <div
                  key={entry.id || idx}
                  className={`flex items-center justify-between p-2.5 rounded-2xl border transition-all ${
                    isCurrentUser
                      ? 'bg-indigo-950/40 border-indigo-500/50 shadow-md'
                      : 'bg-slate-950/40 border-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  {/* Rank + Player details */}
                  <div className="flex items-center gap-3">
                    {getRankMedal(idx)}

                    <div className="flex flex-col">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-slate-100 font-['Fredoka']">
                          {entry.playerName}
                        </span>
                        {isCurrentUser && (
                          <span className="text-[9px] bg-indigo-500 text-white px-1.5 py-0.2 rounded font-black">
                            YOU
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-[10px] text-slate-400">
                        <span className="flex items-center gap-1" style={{ color: birdUsed.primaryColor }}>
                          <span>🐦</span> {birdUsed.name}
                        </span>
                        <span>•</span>
                        <span>{entry.date}</span>
                      </div>
                    </div>
                  </div>

                  {/* Score & Coins */}
                  <div className="flex flex-col items-end">
                    <span className="text-base font-black text-amber-400 font-['Fredoka']">
                      {entry.score} <span className="text-xs font-normal text-amber-300/80">PTS</span>
                    </span>
                    <span className="text-[10px] text-slate-400 font-semibold flex items-center gap-0.5">
                      <span>🪙</span> +{entry.coins}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950/60 border-t border-slate-800 text-center">
          <p className="text-[11px] text-slate-400">
            Scores are saved automatically to your local browser record!
          </p>
        </div>
      </div>
    </div>
  );
};
