import { useRef, useEffect, useCallback } from 'react';
import { BirdConfig, ThemeConfig, GameSettings, Pipe, CoinItem, Particle, Shockwave, FloatingText, DynamicEvent } from '../types/game';
import { sound } from '../services/audio';

interface GameCanvasProps {
  bird: BirdConfig;
  theme: ThemeConfig;
  settings: GameSettings;
  activeEvent: DynamicEvent | null;
  isPlaying: boolean;
  isGameOver: boolean;
  onScoreUpdate: (score: number) => void;
  onCoinCollect: (coinsEarned: number, totalInRun: number) => void;
  onGameOver: (finalScore: number, finalCoins: number, pipesPassed: number, flaps: number) => void;
  onShieldUsed: () => void;
  onFlap?: () => void;
}

export function GameCanvas({
  bird,
  theme,
  settings,
  activeEvent,
  isPlaying,
  isGameOver,
  onScoreUpdate,
  onCoinCollect,
  onGameOver,
  onShieldUsed,
  onFlap,
}: GameCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Core Physics & Coordinates (Canvas internal resolution 360 x 640)
  const CANVAS_WIDTH = 360;
  const CANVAS_HEIGHT = 640;
  const GROUND_HEIGHT = 90;

  // Game loop state refs to prevent closure stale state in requestAnimationFrame
  const gameStateRef = useRef({
    birdY: 280,
    birdVelocity: 0,
    birdRotation: 0,
    wingAngle: 0,
    wingSpeed: 0.25,
    hasActiveShield: bird.hasShield || (activeEvent?.freeShieldOnStart ?? false),
    
    // Statistics for this specific run
    score: 0,
    coins: 0,
    pipesPassed: 0,
    totalFlapsInRun: 0,

    // Obstacles & Pickups
    pipes: [] as Pipe[],
    coinsList: [] as CoinItem[],
    particles: [] as Particle[],
    shockwaves: [] as Shockwave[],
    floatingTexts: [] as FloatingText[],
    ambientParticles: [] as Particle[],

    // Parallax ground offset
    groundOffset: 0,
    mountainOffset: 0,
    cityOffset: 0,
    treeOffset: 0,

    // Timing & animation
    lastTime: performance.now(),
    nextPipeTimer: 0,
    pipeSpawnInterval: 1600, // ms between pipes
    gameTime: 0,
    screenShakeTimer: 0,
    screenShakeIntensity: 0,
  });

  // Re-sync shield if bird/event changes before game start
  useEffect(() => {
    gameStateRef.current.hasActiveShield = bird.hasShield || (activeEvent?.freeShieldOnStart ?? false);
  }, [bird, activeEvent]);

  // Handle User Input (Flap)
  const performFlap = useCallback(() => {
    if (!isPlaying || isGameOver) return;

    const state = gameStateRef.current;
    
    // Physics flap calculation with event and bird modifiers
    const baseFlap = bird.flapStrength;
    const eventGravityMod = activeEvent ? activeEvent.gravityMultiplierMod : 1.0;
    state.birdVelocity = baseFlap * (eventGravityMod < 0.8 ? 0.9 : 1.0);
    state.wingSpeed = 0.6;
    state.totalFlapsInRun += 1;

    sound.playFlap();
    if (onFlap) onFlap();

    // Create flap gust particles & shockwave
    if (settings.graphics.particlesEnabled) {
      // Wind puff shockwave ring
      if (settings.graphics.shockwavesEnabled) {
        state.shockwaves.push({
          x: 100,
          y: state.birdY + 10,
          radius: 6,
          maxRadius: 36,
          color: bird.glowColor || 'rgba(255,255,255,0.6)',
          alpha: 0.7,
          lineWidth: 2.5,
        });
      }

      // Feather / Spark gust particles behind bird
      for (let i = 0; i < 6; i++) {
        const pColor = i % 2 === 0 ? bird.primaryColor : bird.wingColor;
        state.particles.push({
          x: 90 + Math.random() * 8,
          y: state.birdY + 8 + (Math.random() - 0.5) * 12,
          vx: -(Math.random() * 2.5 + 1.2),
          vy: Math.random() * 2.0 - 0.5,
          size: Math.random() * 4 + 2,
          color: pColor,
          alpha: 0.85,
          life: 0,
          maxLife: 28 + Math.random() * 15,
          rotation: Math.random() * Math.PI * 2,
          vRot: (Math.random() - 0.5) * 0.2,
          shape: bird.trailType === 'fire' ? 'spark' : bird.trailType === 'stars' ? 'star' : 'feather',
        });
      }
    }
  }, [isPlaying, isGameOver, bird, settings, activeEvent, onFlap]);

  // Setup Keyboard and Touch/Click Listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
        e.preventDefault();
        performFlap();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [performFlap]);

  // Reset or initialize state on game state transition
  useEffect(() => {
    if (isPlaying) {
      const state = gameStateRef.current;
      state.birdY = 260;
      state.birdVelocity = -4;
      state.birdRotation = 0;
      state.score = 0;
      state.coins = 0;
      state.pipesPassed = 0;
      state.totalFlapsInRun = 0;
      state.hasActiveShield = bird.hasShield || (activeEvent?.freeShieldOnStart ?? false);
      state.pipes = [];
      state.coinsList = [];
      state.particles = [];
      state.shockwaves = [];
      state.floatingTexts = [];
      state.nextPipeTimer = 1100; // initial delay before first pipe
      state.lastTime = performance.now();
      state.screenShakeTimer = 0;

      sound.startBGM();
    } else {
      sound.stopBGM();
    }
  }, [isPlaying, bird, activeEvent]);

  // Main Canvas Rendering & Physics Game Loop
  useEffect(() => {
    let animationFrameId: number;

    // Initialize ambient weather particles (fireflies / petals / stars)
    const initAmbient = () => {
      const amb: Particle[] = [];
      for (let i = 0; i < 28; i++) {
        amb.push({
          x: Math.random() * CANVAS_WIDTH,
          y: Math.random() * (CANVAS_HEIGHT - GROUND_HEIGHT),
          vx: -(Math.random() * 0.4 + 0.1),
          vy: Math.sin(i) * 0.3,
          size: Math.random() * 2.5 + 1.2,
          color: theme.id === 'space' ? '#ffffff' : theme.id === 'cyberpunk' ? '#00ffff' : '#fef08a',
          alpha: Math.random() * 0.6 + 0.2,
          life: Math.random() * 100,
          maxLife: 200,
          shape: theme.weather === 'stars' ? 'star' : theme.weather === 'petals' ? 'feather' : 'circle',
        });
      }
      gameStateRef.current.ambientParticles = amb;
    };
    initAmbient();

    const loop = (currentTime: number) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const state = gameStateRef.current;
      const deltaMs = Math.min(currentTime - state.lastTime, 64);
      const dt = deltaMs / 1000;
      state.lastTime = currentTime;
      state.gameTime += dt;

      // Event modifier calculations
      const speedMod = activeEvent ? activeEvent.speedMultiplierMod : 1.0;
      const gravityMod = activeEvent ? activeEvent.gravityMultiplierMod : 1.0;
      const allGold = activeEvent ? activeEvent.allGoldCoins : false;
      const doubleScore = activeEvent ? activeEvent.doubleScoreMod : false;
      const coinRate = activeEvent ? activeEvent.coinRateMod : 1.0;

      // 1. UPDATE PHYSICS & ENTITIES (IF PLAYING)
      if (isPlaying && !isGameOver) {
        // Bird Gravity & Velocity
        const effectiveGravity = (0.34 * bird.gravityMultiplier * gravityMod);
        state.birdVelocity += effectiveGravity * (deltaMs / 16.66);
        // Terminal velocity
        if (state.birdVelocity > 9.5) state.birdVelocity = 9.5;
        state.birdY += state.birdVelocity * (deltaMs / 16.66);

        // Bird Rotation (smooth tilt based on velocity)
        if (state.birdVelocity < 0) {
          state.birdRotation = Math.max(-0.45, state.birdVelocity * 0.07);
        } else {
          state.birdRotation = Math.min(1.2, (state.birdVelocity - 2) * 0.12);
        }

        // Wing flap animation
        state.wingAngle += state.wingSpeed;
        if (state.wingSpeed > 0.2) state.wingSpeed -= 0.015;

        // Ground & Ceiling Collisions
        const birdHitboxRadius = bird.hitboxRadius;
        const groundY = CANVAS_HEIGHT - GROUND_HEIGHT;

        if (state.birdY + birdHitboxRadius >= groundY) {
          // Hit the ground -> Fatal
          state.birdY = groundY - birdHitboxRadius;
          sound.playHit();
          sound.playGameOver();
          onGameOver(state.score, state.coins, state.pipesPassed, state.totalFlapsInRun);
          return;
        }

        if (state.birdY - birdHitboxRadius <= 0) {
          state.birdY = birdHitboxRadius;
          state.birdVelocity = 0;
        }

        // Spawn Pipes
        state.nextPipeTimer -= deltaMs;
        if (state.nextPipeTimer <= 0) {
          const pipeGap = 135; // height of gap
          const minPipeTop = 60;
          const maxPipeTop = groundY - pipeGap - 60;
          const topHeight = Math.floor(Math.random() * (maxPipeTop - minPipeTop + 1)) + minPipeTop;
          const bottomHeight = groundY - (topHeight + pipeGap);

          state.pipes.push({
            x: CANVAS_WIDTH + 10,
            topHeight,
            bottomHeight,
            width: 58,
            gap: pipeGap,
            passed: false,
            coinSpawned: false,
          });

          // Spawn Coin in pipe gap with coinRate multiplier
          const shouldSpawnCoin = Math.random() < 0.75 * coinRate;
          if (shouldSpawnCoin) {
            let coinVal = 1;
            if (allGold) {
              coinVal = 5;
            } else {
              const r = Math.random();
              if (r < 0.18) coinVal = 5; // Gold (5 coins)
              else if (r < 0.45) coinVal = 2; // Silver (2 coins)
              else coinVal = 1; // Bronze (1 coin)
            }

            state.coinsList.push({
              id: Date.now() + Math.random(),
              x: CANVAS_WIDTH + 10 + 29, // center of pipe
              y: topHeight + pipeGap / 2 + (Math.random() - 0.5) * 35,
              value: coinVal,
              collected: false,
              animOffset: Math.random() * Math.PI * 2,
              scale: 1,
            });
          }

          state.nextPipeTimer = state.pipeSpawnInterval / speedMod;
        }

        // Move & Collide Pipes
        const scrollSpeed = 2.2 * speedMod * (deltaMs / 16.66);
        const birdX = 100;

        for (let i = state.pipes.length - 1; i >= 0; i--) {
          const pipe = state.pipes[i];
          pipe.x -= scrollSpeed;

          // Check passing pipe for score
          if (!pipe.passed && pipe.x + pipe.width < birdX) {
            pipe.passed = true;
            const pointsToAdd = doubleScore ? 2 : 1;
            state.score += pointsToAdd;
            state.pipesPassed += 1;
            sound.playScore();
            onScoreUpdate(state.score);

            // Add floating score popup text
            state.floatingTexts.push({
              id: Math.random(),
              x: birdX + 15,
              y: state.birdY - 15,
              text: doubleScore ? '+2 PTS!' : '+1',
              color: doubleScore ? '#f43f5e' : '#ffffff',
              alpha: 1.0,
              scale: 1.0,
              vy: -1.2,
            });

            // Milestone fanfare confetti every 10 points
            if (state.score % 10 === 0 && settings.graphics.particlesEnabled) {
              for (let k = 0; k < 24; k++) {
                state.particles.push({
                  x: birdX,
                  y: state.birdY,
                  vx: (Math.random() - 0.5) * 6,
                  vy: (Math.random() - 0.8) * 6,
                  size: Math.random() * 5 + 3,
                  color: ['#fbbf24', '#f43f5e', '#38bdf8', '#a855f7', '#34d399'][k % 5],
                  alpha: 1,
                  life: 0,
                  maxLife: 45 + Math.random() * 20,
                  rotation: Math.random() * Math.PI * 2,
                  vRot: (Math.random() - 0.5) * 0.3,
                  shape: 'confetti',
                });
              }
            }
          }

          // Check Collision with Pipe (Top or Bottom)
          const birdLeft = birdX - birdHitboxRadius + 4;
          const birdRight = birdX + birdHitboxRadius - 4;
          const birdTop = state.birdY - birdHitboxRadius + 4;
          const birdBottom = state.birdY + birdHitboxRadius - 4;

          const inPipeX = birdRight > pipe.x && birdLeft < pipe.x + pipe.width;
          const hitTopPipe = inPipeX && birdTop < pipe.topHeight;
          const hitBottomPipe = inPipeX && birdBottom > groundY - pipe.bottomHeight;

          if (hitTopPipe || hitBottomPipe) {
            if (state.hasActiveShield) {
              // Absorb hit with divine shield!
              state.hasActiveShield = false;
              sound.playShieldBreak();
              onShieldUsed();

              // Trigger screen shake
              if (settings.graphics.screenShake) {
                state.screenShakeTimer = 18;
                state.screenShakeIntensity = 7;
              }

              // Create shield shatter burst particles & shockwave
              if (settings.graphics.shockwavesEnabled) {
                state.shockwaves.push({
                  x: birdX,
                  y: state.birdY,
                  radius: 12,
                  maxRadius: 75,
                  color: '#38bdf8',
                  alpha: 1.0,
                  lineWidth: 4,
                });
              }

              for (let p = 0; p < 20; p++) {
                state.particles.push({
                  x: birdX,
                  y: state.birdY,
                  vx: (Math.random() - 0.5) * 7,
                  vy: (Math.random() - 0.5) * 7,
                  size: Math.random() * 4 + 2,
                  color: '#38bdf8',
                  alpha: 1,
                  life: 0,
                  maxLife: 35,
                  shape: 'spark',
                });
              }

              // Bounce the bird backward and push pipe slightly ahead to avoid immediate re-collision
              state.birdVelocity = -5.5;
              pipe.x -= 30;
            } else {
              // Fatal collision
              sound.playHit();
              sound.playGameOver();
              onGameOver(state.score, state.coins, state.pipesPassed, state.totalFlapsInRun);
              return;
            }
          }

          // Remove offscreen pipes
          if (pipe.x + pipe.width < -30) {
            state.pipes.splice(i, 1);
          }
        }

        // Move & Collect Coins
        for (let i = state.coinsList.length - 1; i >= 0; i--) {
          const coin = state.coinsList[i];
          coin.x -= scrollSpeed;

          // Magnet ability pull towards bird
          if (bird.magnetRadius > 0 && !coin.collected) {
            const dx = birdX - coin.x;
            const dy = state.birdY - coin.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < bird.magnetRadius) {
              const pullFactor = 4.5 * (1 - dist / bird.magnetRadius);
              coin.x += (dx / dist) * pullFactor;
              coin.y += (dy / dist) * pullFactor;
            }
          }

          // Check coin collection
          if (!coin.collected) {
            const dx = birdX - coin.x;
            const dy = state.birdY - coin.y;
            const dist = Math.sqrt(dx * dx + dy * dy);

            if (dist < birdHitboxRadius + 15) {
              coin.collected = true;
              const multiplier = bird.coinMultiplier;
              const earnedCoins = Math.round(coin.value * multiplier);
              state.coins += earnedCoins;
              sound.playCoin();
              onCoinCollect(earnedCoins, state.coins);

              // Add floating coin text
              state.floatingTexts.push({
                id: Math.random(),
                x: coin.x,
                y: coin.y - 12,
                text: `+${earnedCoins} 🪙`,
                color: coin.value === 5 ? '#f59e0b' : coin.value === 2 ? '#94a3b8' : '#cd7f32',
                alpha: 1.0,
                scale: coin.value === 5 ? 1.3 : 1.0,
                vy: -1.4,
              });

              // Coin sparkle burst particles
              if (settings.graphics.particlesEnabled) {
                const coinColor = coin.value === 5 ? '#fbbf24' : coin.value === 2 ? '#e2e8f0' : '#d97706';
                for (let c = 0; c < 10; c++) {
                  state.particles.push({
                    x: coin.x,
                    y: coin.y,
                    vx: (Math.random() - 0.5) * 4,
                    vy: (Math.random() - 0.5) * 4,
                    size: Math.random() * 3 + 2,
                    color: coinColor,
                    alpha: 1,
                    life: 0,
                    maxLife: 24,
                    shape: 'spark',
                  });
                }
              }
            }
          }

          // Remove collected or offscreen coins
          if (coin.collected || coin.x < -30) {
            state.coinsList.splice(i, 1);
          }
        }

        // Parallax ground & landscape movement
        state.groundOffset = (state.groundOffset + scrollSpeed) % 24;
        state.mountainOffset = (state.mountainOffset + scrollSpeed * 0.15) % CANVAS_WIDTH;
        state.cityOffset = (state.cityOffset + scrollSpeed * 0.35) % CANVAS_WIDTH;
        state.treeOffset = (state.treeOffset + scrollSpeed * 0.65) % CANVAS_WIDTH;
      } else {
        // Idle bobbing animation in Menu
        state.birdY = 270 + Math.sin(state.gameTime * 3.5) * 9;
        state.birdRotation = Math.sin(state.gameTime * 3.5) * 0.08;
        state.wingAngle += 0.18;
        state.groundOffset = (state.groundOffset + 1.2) % 24;
      }

      // Update Screen Shake
      let shakeX = 0;
      let shakeY = 0;
      if (state.screenShakeTimer > 0) {
        state.screenShakeTimer--;
        shakeX = (Math.random() - 0.5) * state.screenShakeIntensity;
        shakeY = (Math.random() - 0.5) * state.screenShakeIntensity;
      }

      // 2. CANVAS DRAWING
      ctx.save();
      if (shakeX !== 0 || shakeY !== 0) {
        ctx.translate(shakeX, shakeY);
      }

      // 2a. Sky Gradient
      const skyGrad = ctx.createLinearGradient(0, 0, 0, CANVAS_HEIGHT - GROUND_HEIGHT);
      skyGrad.addColorStop(0, theme.skyTop);
      skyGrad.addColorStop(1, theme.skyBottom);
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      // Event Atmosphere Hue Overlay
      if (activeEvent?.bgTint) {
        ctx.fillStyle = activeEvent.bgTint;
        ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      }

      // 2b. Ambient Sky Elements (Sun / Moon)
      ctx.save();
      if (theme.id === 'night' || theme.id === 'space') {
        // Moon with soft celestial glow
        ctx.fillStyle = 'rgba(254, 240, 138, 0.15)';
        ctx.beginPath();
        ctx.arc(290, 85, 34, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(290, 85, 20, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Warm Arcade Sun
        ctx.fillStyle = 'rgba(253, 224, 71, 0.18)';
        ctx.beginPath();
        ctx.arc(290, 75, 42, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fde047';
        ctx.beginPath();
        ctx.arc(290, 75, 24, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      // 2c. Parallax Mountain Silhouettes
      ctx.fillStyle = theme.mountainsColor;
      for (let m = -1; m <= 2; m++) {
        const mx = m * 200 - (state.mountainOffset % 200);
        ctx.beginPath();
        ctx.moveTo(mx - 40, CANVAS_HEIGHT - GROUND_HEIGHT);
        ctx.lineTo(mx + 70, CANVAS_HEIGHT - GROUND_HEIGHT - 120);
        ctx.lineTo(mx + 180, CANVAS_HEIGHT - GROUND_HEIGHT);
        ctx.fill();
      }

      // 2d. Parallax Trees / City Background Layer
      ctx.fillStyle = theme.treesColor;
      for (let t = -1; t <= 3; t++) {
        const tx = t * 140 - (state.treeOffset % 140);
        ctx.beginPath();
        ctx.arc(tx + 40, CANVAS_HEIGHT - GROUND_HEIGHT - 35, 35, 0, Math.PI * 2);
        ctx.arc(tx + 75, CANVAS_HEIGHT - GROUND_HEIGHT - 45, 42, 0, Math.PI * 2);
        ctx.arc(tx + 110, CANVAS_HEIGHT - GROUND_HEIGHT - 32, 32, 0, Math.PI * 2);
        ctx.fill();
      }

      // 2e. Draw Ambient Particles (Stars / Fireflies / Petals)
      state.ambientParticles.forEach((p) => {
        p.x += p.vx;
        p.y += Math.sin(state.gameTime * 2 + p.life) * 0.35;
        if (p.x < -10) p.x = CANVAS_WIDTH + 10;
        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // 2f. Draw Pipes
      state.pipes.forEach((pipe) => {
        const groundY = CANVAS_HEIGHT - GROUND_HEIGHT;
        const rimHeight = 22;
        const rimOverhang = 5;

        // --- TOP PIPE ---
        // Main Pipe Stem
        const topGrad = ctx.createLinearGradient(pipe.x, 0, pipe.x + pipe.width, 0);
        topGrad.addColorStop(0, theme.pipeColor);
        topGrad.addColorStop(0.35, theme.pipeHighlight);
        topGrad.addColorStop(1, theme.pipeDark);
        ctx.fillStyle = topGrad;
        ctx.fillRect(pipe.x, 0, pipe.width, pipe.topHeight - rimHeight);

        // Top Pipe Rim / Collar
        ctx.fillStyle = theme.pipeRim;
        ctx.fillRect(
          pipe.x - rimOverhang,
          pipe.topHeight - rimHeight,
          pipe.width + rimOverhang * 2,
          rimHeight
        );
        // Rim Highlight stripe
        ctx.fillStyle = 'rgba(255,255,255,0.3)';
        ctx.fillRect(pipe.x + 6, pipe.topHeight - rimHeight + 2, 8, rimHeight - 4);

        // --- BOTTOM PIPE ---
        const bottomY = groundY - pipe.bottomHeight;
        // Bottom Pipe Rim / Collar
        ctx.fillStyle = theme.pipeRim;
        ctx.fillRect(
          pipe.x - rimOverhang,
          bottomY,
          pipe.width + rimOverhang * 2,
          rimHeight
        );
        ctx.fillStyle = 'rgba(255,255,255,0.3)';
        ctx.fillRect(pipe.x + 6, bottomY + 2, 8, rimHeight - 4);

        // Bottom Pipe Stem
        const botGrad = ctx.createLinearGradient(pipe.x, 0, pipe.x + pipe.width, 0);
        botGrad.addColorStop(0, theme.pipeColor);
        botGrad.addColorStop(0.35, theme.pipeHighlight);
        botGrad.addColorStop(1, theme.pipeDark);
        ctx.fillStyle = botGrad;
        ctx.fillRect(
          pipe.x,
          bottomY + rimHeight,
          pipe.width,
          pipe.bottomHeight - rimHeight
        );
      });

      // 2g. Draw Coins with 3D Shimmer Rotation
      state.coinsList.forEach((coin) => {
        if (coin.collected) return;
        const pulse = Math.sin(state.gameTime * 5 + coin.animOffset);
        const widthScale = Math.abs(Math.cos(state.gameTime * 4 + coin.animOffset));

        ctx.save();
        ctx.translate(coin.x, coin.y + pulse * 4);

        const radius = coin.value === 5 ? 13 : coin.value === 2 ? 11 : 10;
        const mainColor = coin.value === 5 ? '#f59e0b' : coin.value === 2 ? '#cbd5e1' : '#cd7f32';
        const innerColor = coin.value === 5 ? '#fef08a' : coin.value === 2 ? '#ffffff' : '#fde68a';

        // Outer Coin Shimmer Glow
        ctx.fillStyle = coin.value === 5 ? 'rgba(245, 158, 11, 0.4)' : 'rgba(255, 255, 255, 0.25)';
        ctx.beginPath();
        ctx.ellipse(0, 0, (radius + 4) * widthScale, radius + 4, 0, 0, Math.PI * 2);
        ctx.fill();

        // Coin Outer Disc
        ctx.fillStyle = mainColor;
        ctx.beginPath();
        ctx.ellipse(0, 0, radius * widthScale, radius, 0, 0, Math.PI * 2);
        ctx.fill();

        // Coin Inner Emboss
        ctx.fillStyle = innerColor;
        ctx.beginPath();
        ctx.ellipse(0, 0, (radius - 3) * widthScale, radius - 3, 0, 0, Math.PI * 2);
        ctx.fill();

        // Star / Value mark
        if (widthScale > 0.4) {
          ctx.fillStyle = mainColor;
          ctx.font = 'bold 9px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(coin.value === 5 ? '★' : `${coin.value}`, 0, 0);
        }

        ctx.restore();
      });

      // 2h. Draw Particle Effects
      for (let pIdx = state.particles.length - 1; pIdx >= 0; pIdx--) {
        const p = state.particles[pIdx];
        p.life++;
        p.x += p.vx;
        p.y += p.vy;
        p.alpha = Math.max(0, 1 - p.life / p.maxLife);
        if (p.vRot) p.rotation = (p.rotation || 0) + p.vRot;

        if (p.life >= p.maxLife) {
          state.particles.splice(pIdx, 1);
          continue;
        }

        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.translate(p.x, p.y);
        if (p.rotation) ctx.rotate(p.rotation);

        ctx.fillStyle = p.color;
        if (p.shape === 'confetti') {
          ctx.fillRect(-p.size, -p.size / 2, p.size * 2, p.size);
        } else if (p.shape === 'star') {
          ctx.beginPath();
          for (let s = 0; s < 5; s++) {
            ctx.lineTo(Math.cos((18 + s * 72) * Math.PI / 180) * p.size, -Math.sin((18 + s * 72) * Math.PI / 180) * p.size);
            ctx.lineTo(Math.cos((54 + s * 72) * Math.PI / 180) * (p.size / 2), -Math.sin((54 + s * 72) * Math.PI / 180) * (p.size / 2));
          }
          ctx.closePath();
          ctx.fill();
        } else if (p.shape === 'feather') {
          ctx.beginPath();
          ctx.ellipse(0, 0, p.size * 1.8, p.size * 0.8, 0, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.beginPath();
          ctx.arc(0, 0, p.size, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }

      // 2i. Draw Expanding Shockwaves
      for (let sIdx = state.shockwaves.length - 1; sIdx >= 0; sIdx--) {
        const sw = state.shockwaves[sIdx];
        sw.radius += (sw.maxRadius - sw.radius) * 0.14 + 1.2;
        sw.alpha = Math.max(0, 1 - sw.radius / sw.maxRadius);

        if (sw.radius >= sw.maxRadius || sw.alpha <= 0.02) {
          state.shockwaves.splice(sIdx, 1);
          continue;
        }

        ctx.save();
        ctx.globalAlpha = sw.alpha;
        ctx.strokeStyle = sw.color;
        ctx.lineWidth = sw.lineWidth;
        ctx.beginPath();
        ctx.arc(sw.x, sw.y, sw.radius, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }

      // 2j. Draw Main Character (Bird)
      const birdX = 100;
      ctx.save();
      ctx.translate(birdX, state.birdY);
      ctx.rotate(state.birdRotation);

      // Character Aura / Shield
      if (state.hasActiveShield) {
        ctx.save();
        const shieldPulse = Math.sin(state.gameTime * 6) * 3;
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.85)';
        ctx.lineWidth = 3;
        ctx.fillStyle = 'rgba(56, 189, 248, 0.2)';
        ctx.beginPath();
        ctx.arc(0, 0, bird.hitboxRadius + 11 + shieldPulse, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      }

      // Bird Glow Aura
      if (bird.glowColor) {
        ctx.save();
        ctx.fillStyle = bird.glowColor;
        ctx.globalAlpha = 0.35;
        ctx.beginPath();
        ctx.arc(0, 0, bird.hitboxRadius + 8, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Bird Body Outer
      ctx.fillStyle = bird.primaryColor;
      ctx.beginPath();
      ctx.arc(0, 0, bird.hitboxRadius + 2, 0, Math.PI * 2);
      ctx.fill();

      // Bird Belly / Gradient
      ctx.fillStyle = bird.bellyColor;
      ctx.beginPath();
      ctx.arc(2, 4, bird.hitboxRadius - 3, 0, Math.PI * 2);
      ctx.fill();

      // Bird Wing with Flap Animation
      const wingYOffset = Math.sin(state.wingAngle) * 6;
      ctx.fillStyle = bird.wingColor;
      ctx.beginPath();
      ctx.ellipse(-5, wingYOffset, 8, 5, -0.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.15)';
      ctx.lineWidth = 1.2;
      ctx.stroke();

      // Bird Eye (White background + Pupil + Glint)
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(6, -5, 5.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = bird.eyeColor || '#0f172a';
      ctx.beginPath();
      ctx.arc(7.5, -5, 2.8, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(8.5, -6.5, 1.2, 0, Math.PI * 2);
      ctx.fill();

      // Bird Beak
      ctx.fillStyle = bird.beakColor;
      ctx.beginPath();
      ctx.moveTo(9, -2);
      ctx.lineTo(19, 1);
      ctx.lineTo(9, 6);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.15)';
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.restore();

      // 2k. Draw Ground Platform Layer
      const groundY = CANVAS_HEIGHT - GROUND_HEIGHT;
      // Grass Top Strip
      ctx.fillStyle = theme.groundTop;
      ctx.fillRect(0, groundY, CANVAS_WIDTH, 14);

      // Grass Blade pattern
      ctx.fillStyle = 'rgba(0,0,0,0.12)';
      for (let g = -1; g < CANVAS_WIDTH / 12 + 2; g++) {
        const gx = g * 12 - state.groundOffset;
        ctx.beginPath();
        ctx.moveTo(gx, groundY);
        ctx.lineTo(gx + 6, groundY + 10);
        ctx.lineTo(gx + 12, groundY);
        ctx.fill();
      }

      // Ground Soil Body
      ctx.fillStyle = theme.groundBody;
      ctx.fillRect(0, groundY + 14, CANVAS_WIDTH, GROUND_HEIGHT - 14);

      // Soil texture dashes
      ctx.fillStyle = 'rgba(255,255,255,0.08)';
      for (let s = 0; s < 12; s++) {
        const sx = ((s * 48 - state.groundOffset * 2) % CANVAS_WIDTH + CANVAS_WIDTH) % CANVAS_WIDTH;
        ctx.fillRect(sx, groundY + 28 + (s % 3) * 16, 16, 4);
      }

      // 2l. Draw Floating Popup Texts (+1, +5★, +2 PTS)
      for (let tIdx = state.floatingTexts.length - 1; tIdx >= 0; tIdx--) {
        const ft = state.floatingTexts[tIdx];
        ft.y += ft.vy;
        ft.alpha -= 0.022;

        if (ft.alpha <= 0) {
          state.floatingTexts.splice(tIdx, 1);
          continue;
        }

        ctx.save();
        ctx.globalAlpha = ft.alpha;
        ctx.font = `bold ${Math.round(16 * ft.scale)}px sans-serif`;
        ctx.fillStyle = ft.color;
        ctx.shadowColor = 'rgba(0,0,0,0.7)';
        ctx.shadowBlur = 4;
        ctx.textAlign = 'center';
        ctx.fillText(ft.text, ft.x, ft.y);
        ctx.restore();
      }

      ctx.restore(); // Restore shake translation

      // Continue animation loop
      animationFrameId = requestAnimationFrame(loop);
    };

    animationFrameId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animationFrameId);
  }, [isPlaying, isGameOver, bird, theme, settings, activeEvent, onScoreUpdate, onCoinCollect, onGameOver, onShieldUsed]);

  return (
    <canvas
      ref={canvasRef}
      id="flappy-game-canvas"
      width={CANVAS_WIDTH}
      height={CANVAS_HEIGHT}
      onClick={performFlap}
      className="w-full h-full object-contain cursor-pointer select-none touch-none"
    />
  );
}
