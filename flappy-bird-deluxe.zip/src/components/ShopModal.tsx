import React, { useState } from 'react';
import { BirdConfig, PlayerStats } from '../types/game';
import { BIRDS } from '../constants/birds';
import { sound } from '../services/audio';
import { X, Check, Lock, Shield, Zap, Sparkles, Magnet, Feather, Info } from 'lucide-react';

interface ShopModalProps {
  stats: PlayerStats;
  selectedBird: BirdConfig;
  onClose: () => void;
  onBuyBird: (bird: BirdConfig) => void;
  onEquipBird: (birdId: string) => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({
  stats,
  selectedBird,
  onClose,
  onBuyBird,
  onEquipBird,
}) => {
  const [activeBirdId, setActiveBirdId] = useState<string>(selectedBird.id);
  const currentBird = BIRDS.find((b) => b.id === activeBirdId) || BIRDS[0];
  const isUnlocked = stats.unlockedBirds.includes(currentBird.id);
  const isEquipped = stats.selectedBirdId === currentBird.id;
  const canAfford = stats.totalCoins >= currentBird.price;

  const handleSelectBird = (bird: BirdConfig) => {
    sound.playClick();
    setActiveBirdId(bird.id);
  };

  const handleBuy = () => {
    if (!canAfford) return;
    sound.playBuy();
    onBuyBird(currentBird);
  };

  const handleEquip = () => {
    sound.playClick();
    onEquipBird(currentBird.id);
  };

  const getRarityBadge = (rarity: string) => {
    switch (rarity) {
      case 'Mythic':
        return 'bg-gradient-to-r from-amber-500 via-pink-500 to-purple-500 text-white shadow-amber-500/20';
      case 'Legendary':
        return 'bg-amber-500/20 text-amber-300 border border-amber-500/40';
      case 'Epic':
        return 'bg-purple-500/20 text-purple-300 border border-purple-500/40';
      case 'Rare':
        return 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40';
      default:
        return 'bg-slate-700/60 text-slate-300 border border-slate-600';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border-2 border-slate-700/90 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-2.5">
            <span className="text-2xl">🏪</span>
            <div>
              <h2 className="text-xl font-bold text-slate-100 font-['Fredoka']">AVIARY SHOP</h2>
              <p className="text-xs text-slate-400">Unlock unique birds with powerful flight perks</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Wallet */}
            <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-950/60 border border-amber-500/50 rounded-full text-amber-300 font-bold text-sm">
              <span>🪙</span>
              <span className="font-['Fredoka'] font-black">{stats.totalCoins}</span>
            </div>

            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Birds Grid Selector */}
        <div className="p-3 bg-slate-950/30 border-b border-slate-800">
          <div className="grid grid-cols-4 gap-2">
            {BIRDS.map((b) => {
              const unlocked = stats.unlockedBirds.includes(b.id);
              const isCurrent = b.id === activeBirdId;
              const equipped = stats.selectedBirdId === b.id;

              return (
                <button
                  key={b.id}
                  onClick={() => handleSelectBird(b)}
                  className={`relative p-2 rounded-2xl flex flex-col items-center gap-1 transition-all border-2 ${
                    isCurrent
                      ? 'border-amber-400 bg-slate-800 shadow-md scale-105'
                      : 'border-slate-800 bg-slate-900/80 hover:border-slate-700'
                  }`}
                >
                  {/* Equipped pill */}
                  {equipped && (
                    <div className="absolute -top-1.5 -right-1.5 bg-emerald-500 text-slate-950 rounded-full p-0.5 shadow">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                  )}

                  {/* Lock icon if not unlocked */}
                  {!unlocked && (
                    <div className="absolute top-1 left-1 text-slate-500">
                      <Lock className="w-3 h-3" />
                    </div>
                  )}

                  {/* Bird Avatar */}
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center border transition-transform"
                    style={{
                      backgroundColor: `${b.primaryColor}20`,
                      borderColor: b.primaryColor,
                    }}
                  >
                    <div
                      className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                      style={{ backgroundColor: b.primaryColor }}
                    >
                      <span>🐦</span>
                    </div>
                  </div>

                  <span className="text-[11px] font-bold truncate max-w-full text-slate-200">{b.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Bird Detailed Showcase Panel */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 flex flex-col gap-4">
          <div className="flex flex-col sm:flex-row items-center gap-4 bg-slate-950/60 border border-slate-800 rounded-2xl p-4">
            {/* Big Bird Visual preview */}
            <div
              className="w-24 h-24 rounded-3xl flex items-center justify-center border-4 shadow-lg shrink-0 transition-transform duration-300 hover:scale-105"
              style={{
                backgroundColor: `${currentBird.primaryColor}25`,
                borderColor: currentBird.primaryColor,
                boxShadow: currentBird.glowColor ? `0 0 25px ${currentBird.glowColor}` : 'none',
              }}
            >
              <div
                className="w-14 h-14 rounded-full flex items-center justify-center font-bold text-2xl"
                style={{ backgroundColor: currentBird.primaryColor }}
              >
                <span>🐦</span>
              </div>
            </div>

            {/* Bird Title & Description */}
            <div className="flex-1 text-center sm:text-left">
              <div className="flex items-center justify-center sm:justify-start gap-2 mb-1">
                <h3 className="text-2xl font-black text-slate-100 font-['Fredoka']">{currentBird.name}</h3>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${getRarityBadge(currentBird.rarity)}`}>
                  {currentBird.rarity}
                </span>
              </div>
              <p className="text-xs font-semibold text-amber-400 mb-1.5">{currentBird.title}</p>
              <p className="text-xs text-slate-300 leading-relaxed">{currentBird.description}</p>
            </div>
          </div>

          {/* Stats & Perk Matrix */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {/* Special Ability Card */}
            <div className="sm:col-span-2 p-3 bg-indigo-950/40 border border-indigo-500/40 rounded-xl flex items-start gap-3">
              <div className="p-2 rounded-lg bg-indigo-500/20 text-indigo-300 mt-0.5">
                {currentBird.ability === 'shield' && <Shield className="w-5 h-5 text-emerald-400" />}
                {currentBird.ability === 'double_coins' && <Zap className="w-5 h-5 text-cyan-400" />}
                {currentBird.ability === 'coin_magnet' && <Magnet className="w-5 h-5 text-sky-400" />}
                {currentBird.ability === 'glide' && <Feather className="w-5 h-5 text-rose-400" />}
                {currentBird.ability === 'celestial_mastery' && <Sparkles className="w-5 h-5 text-amber-400" />}
                {currentBird.ability === 'none' && <Info className="w-5 h-5 text-slate-400" />}
                {currentBird.ability === 'smaller_hitbox' && <Sparkles className="w-5 h-5 text-purple-400" />}
                {currentBird.ability === 'floaty_wings' && <Feather className="w-5 h-5 text-pink-400" />}
              </div>
              <div>
                <span className="text-[11px] font-bold text-indigo-300 uppercase tracking-wider">Unique Ability</span>
                <h4 className="font-bold text-sm text-slate-100">{currentBird.abilityName}</h4>
                <p className="text-xs text-slate-300 leading-normal mt-0.5">{currentBird.abilityDesc}</p>
              </div>
            </div>

            {/* Stat: Coin Multiplier */}
            <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-xl flex items-center justify-between">
              <span className="text-xs text-slate-400">Coin Multiplier</span>
              <span className="font-bold text-amber-400 text-sm font-['Fredoka']">{currentBird.coinMultiplier}x</span>
            </div>

            {/* Stat: Gravity Float */}
            <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-xl flex items-center justify-between">
              <span className="text-xs text-slate-400">Gravity Drag</span>
              <span className="font-bold text-emerald-400 text-sm font-['Fredoka']">
                {currentBird.gravityMultiplier < 1.0 ? 'Floaty Light' : 'Standard'}
              </span>
            </div>

            {/* Stat: Hitbox Safety */}
            <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-xl flex items-center justify-between">
              <span className="text-xs text-slate-400">Hitbox Profile</span>
              <span className="font-bold text-purple-400 text-sm font-['Fredoka']">
                {currentBird.hitboxRadius < 13 ? 'Slim (Easy Pass)' : 'Standard'}
              </span>
            </div>

            {/* Stat: Magnet Range */}
            <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-xl flex items-center justify-between">
              <span className="text-xs text-slate-400">Magnet Vacuum</span>
              <span className="font-bold text-sky-400 text-sm font-['Fredoka']">
                {currentBird.magnetRadius > 0 ? `${currentBird.magnetRadius}px Radius` : 'None'}
              </span>
            </div>
          </div>
        </div>

        {/* Footer Action Bar */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/70 flex items-center justify-between gap-3">
          {!isUnlocked ? (
            <button
              onClick={handleBuy}
              disabled={!canAfford}
              className={`w-full py-3.5 px-6 rounded-2xl font-black text-base uppercase font-['Fredoka'] tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg ${
                canAfford
                  ? 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-amber-500/20 active:scale-95'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
              }`}
            >
              <span>UNLOCK FOR</span>
              <span className="flex items-center gap-1 text-lg">
                🪙 {currentBird.price}
              </span>
            </button>
          ) : isEquipped ? (
            <button
              disabled
              className="w-full py-3.5 px-6 rounded-2xl bg-emerald-950/80 border-2 border-emerald-500/60 text-emerald-300 font-bold text-base uppercase font-['Fredoka'] flex items-center justify-center gap-2 cursor-default"
            >
              <Check className="w-5 h-5 stroke-[3]" />
              <span>CURRENTLY EQUIPPED</span>
            </button>
          ) : (
            <button
              onClick={handleEquip}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-400 hover:to-indigo-500 text-white font-black text-base uppercase font-['Fredoka'] tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/25 active:scale-95 transition-all"
            >
              <Check className="w-5 h-5" />
              <span>EQUIP {currentBird.name.toUpperCase()}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
