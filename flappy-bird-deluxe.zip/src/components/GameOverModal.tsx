import { motion } from 'motion/react';
import { RotateCcw, Home, ShoppingBag, Trophy, Gift, Sparkles } from 'lucide-react';
import { PlayerStats, BirdConfig, DailyQuest } from '../types/game';
import { sound } from '../services/audio';

interface GameOverModalProps {
  score: number;
  coinsEarned: number;
  isNewHighScore: boolean;
  stats: PlayerStats;
  bird: BirdConfig;
  completedQuestsInRun: DailyQuest[];
  onRestart: () => void;
  onGoHome: () => void;
  onOpenShop: () => void;
  onOpenLeaderboard: () => void;
  onOpenQuests: () => void;
}

export function GameOverModal({
  score,
  coinsEarned,
  isNewHighScore,
  stats,
  completedQuestsInRun,
  onRestart,
  onGoHome,
  onOpenShop,
  onOpenLeaderboard,
  onOpenQuests,
}: GameOverModalProps) {
  // Compute Classic Medal Tier
  const getMedal = (pts: number) => {
    if (pts >= 40) return { name: 'Platinum Pilot', icon: '🏆', border: 'border-cyan-400', text: 'text-cyan-300' };
    if (pts >= 25) return { name: 'Gold Ace', icon: '🥇', border: 'border-yellow-400', text: 'text-yellow-300' };
    if (pts >= 15) return { name: 'Silver Wing', icon: '🥈', border: 'border-slate-300', text: 'text-slate-200' };
    if (pts >= 8) return { name: 'Bronze Aviator', icon: '🥉', border: 'border-amber-700', text: 'text-amber-500' };
    return null;
  };

  const medal = getMedal(score);

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm pointer-events-auto select-none">
      <motion.div
        initial={{ scale: 0.85, opacity: 0, y: 16 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        transition={{ type: 'spring', damping: 22, stiffness: 320 }}
        className="w-full max-w-[320px] bg-slate-900 border-2 border-slate-700 rounded-3xl p-5 shadow-2xl flex flex-col items-center text-slate-100"
      >
        {/* Title Badge */}
        <h2 className="text-3xl font-black text-amber-400 tracking-tight mb-3 drop-shadow-md">
          {isNewHighScore ? 'NEW BEST!' : 'GAME OVER'}
        </h2>

        {/* Classic Scoreboard Box */}
        <div className="w-full bg-slate-950/80 border-2 border-slate-800 rounded-2xl p-4 mb-3 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-slate-400 tracking-wider">SCORE</span>
            <span className="text-3xl font-black text-white">{score}</span>
          </div>

          <div className="flex items-center justify-between border-t border-slate-800 pt-2">
            <span className="text-xs font-black text-slate-400 tracking-wider">BEST</span>
            <span className="text-xl font-black text-amber-400">{stats.highScore}</span>
          </div>

          <div className="flex items-center justify-between border-t border-slate-800 pt-2">
            <span className="text-xs font-black text-slate-400 tracking-wider">COINS</span>
            <div className="flex items-center gap-1 font-extrabold text-amber-300">
              <span>+{coinsEarned}</span>
              <span>🪙</span>
            </div>
          </div>

          {/* Medal Badge If Earned */}
          {medal && (
            <div className={`flex items-center justify-between border-t border-slate-800 pt-2`}>
              <span className="text-xs font-black text-slate-400 tracking-wider">MEDAL</span>
              <div className="flex items-center gap-1.5">
                <span className="text-base">{medal.icon}</span>
                <span className={`text-xs font-bold ${medal.text}`}>{medal.name}</span>
              </div>
            </div>
          )}
        </div>

        {/* Quest Completed Banner Notification */}
        {completedQuestsInRun.length > 0 && (
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            onClick={() => {
              sound.playClick();
              onOpenQuests();
            }}
            className="w-full p-2 mb-3 bg-amber-500/15 border border-amber-500/40 rounded-xl flex items-center justify-between cursor-pointer hover:bg-amber-500/25 transition-colors"
          >
            <div className="flex items-center gap-2">
              <Gift className="w-4 h-4 text-amber-400" />
              <div className="text-left">
                <div className="text-xs font-bold text-amber-300">
                  {completedQuestsInRun.length} Quest Complete!
                </div>
                <div className="text-[10px] text-slate-300">Tap to claim coin rewards</div>
              </div>
            </div>
            <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
          </motion.div>
        )}

        {/* Primary Restart Button */}
        <motion.button
          whileHover={{ scale: 1.04 }}
          whileTap={{ scale: 0.96 }}
          onClick={() => {
            sound.playClick();
            onRestart();
          }}
          className="w-full py-3 px-6 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-base shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 transition-all cursor-pointer mb-2.5"
        >
          <RotateCcw className="w-4 h-4 stroke-[3]" />
          <span>PLAY AGAIN</span>
        </motion.button>

        {/* Secondary Navigation Row */}
        <div className="grid grid-cols-4 gap-2 w-full">
          <button
            onClick={() => {
              sound.playClick();
              onGoHome();
            }}
            className="py-2 px-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer"
            title="Main Menu"
          >
            <Home className="w-4 h-4" />
            <span className="text-[10px]">Menu</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onOpenShop();
            }}
            className="py-2 px-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer"
            title="Aviary Shop"
          >
            <ShoppingBag className="w-4 h-4 text-amber-400" />
            <span className="text-[10px]">Aviary</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onOpenLeaderboard();
            }}
            className="py-2 px-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer"
            title="Leaderboard"
          >
            <Trophy className="w-4 h-4 text-yellow-400" />
            <span className="text-[10px]">Ranks</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onOpenQuests();
            }}
            className="py-2 px-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 flex flex-col items-center justify-center gap-1 transition-colors relative cursor-pointer"
            title="Daily Quests"
          >
            <Gift className="w-4 h-4 text-amber-400" />
            <span className="text-[10px]">Quests</span>
            {completedQuestsInRun.length > 0 && (
              <span className="w-2 h-2 rounded-full bg-rose-500 absolute top-1 right-1"></span>
            )}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
