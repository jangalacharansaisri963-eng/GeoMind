import { motion, AnimatePresence } from 'motion/react';
import { X, CheckCircle2, Gift, Sparkles, Trophy, Award, Milestone, Coins, PlaneTakeoff, Feather, Bird } from 'lucide-react';
import { DailyQuest } from '../types/game';
import { sound } from '../services/audio';

interface DailyQuestsModalProps {
  quests: DailyQuest[];
  onClaimQuest: (questId: string) => void;
  onClose: () => void;
}

export function DailyQuestsModal({ quests, onClaimQuest, onClose }: DailyQuestsModalProps) {
  const completedUnclaimed = quests.filter((q) => q.completed && !q.claimed).length;

  const getQuestIcon = (iconName: string) => {
    switch (iconName) {
      case 'Milestone':
        return <Milestone className="w-5 h-5 text-emerald-400" />;
      case 'Coins':
        return <Coins className="w-5 h-5 text-amber-400" />;
      case 'PlaneTakeoff':
        return <PlaneTakeoff className="w-5 h-5 text-sky-400" />;
      case 'Feather':
        return <Feather className="w-5 h-5 text-violet-400" />;
      case 'Bird':
        return <Bird className="w-5 h-5 text-pink-400" />;
      default:
        return <Trophy className="w-5 h-5 text-amber-400" />;
    }
  };

  const handleClaim = (questId: string) => {
    sound.playUnlock();
    onClaimQuest(questId);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 15 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-2xl p-6 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden text-slate-100"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-amber-500/10 border border-amber-500/20 rounded-xl">
                <Gift className="w-6 h-6 text-amber-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
                  Daily Expeditions
                  {completedUnclaimed > 0 && (
                    <span className="px-2 py-0.5 text-xs font-semibold bg-amber-500 text-slate-950 rounded-full">
                      {completedUnclaimed} Ready
                    </span>
                  )}
                </h2>
                <p className="text-xs text-slate-400">Resets every 24 hours with fresh bonus rewards</p>
              </div>
            </div>
            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quests List */}
          <div className="flex-1 overflow-y-auto my-4 space-y-3.5 pr-1">
            {quests.map((quest) => {
              const progressPct = Math.min(100, Math.round((quest.progress / quest.target) * 100));

              return (
                <div
                  key={quest.id}
                  className={`p-4 rounded-xl border transition-all ${
                    quest.claimed
                      ? 'bg-slate-900/60 border-slate-800/60 opacity-60'
                      : quest.completed
                      ? 'bg-amber-950/20 border-amber-500/40 shadow-lg shadow-amber-500/5'
                      : 'bg-slate-800/40 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 rounded-lg bg-slate-800/90 border border-slate-700/60">
                        {getQuestIcon(quest.icon)}
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-slate-100">{quest.title}</h3>
                        <p className="text-xs text-slate-400">{quest.description}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-1 font-bold text-amber-400 text-xs px-2 py-1 bg-amber-500/10 rounded-lg border border-amber-500/20 whitespace-nowrap">
                      <span>+{quest.rewardCoins}</span>
                      <span>🪙</span>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="mt-3">
                    <div className="flex justify-between items-center text-xs mb-1.5 font-medium">
                      <span className="text-slate-400">
                        Progress: {quest.progress} / {quest.target}
                      </span>
                      <span className={quest.completed ? 'text-emerald-400 font-bold' : 'text-slate-400'}>
                        {progressPct}%
                      </span>
                    </div>
                    <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                      <div
                        className={`h-full transition-all duration-500 ${
                          quest.completed
                            ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                            : 'bg-gradient-to-r from-amber-500 to-yellow-400'
                        }`}
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>
                  </div>

                  {/* Action Button */}
                  <div className="mt-3 flex justify-end">
                    {quest.claimed ? (
                      <span className="flex items-center gap-1.5 text-xs text-slate-500 font-semibold py-1">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                        Claimed
                      </span>
                    ) : quest.completed ? (
                      <motion.button
                        whileHover={{ scale: 1.03 }}
                        whileTap={{ scale: 0.97 }}
                        onClick={() => handleClaim(quest.id)}
                        className="flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 text-xs font-bold rounded-lg shadow-md transition-all"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        Claim Reward (+{quest.rewardCoins} 🪙)
                      </motion.button>
                    ) : (
                      <span className="text-xs text-slate-500 italic py-1">In progress</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Footer Info */}
          <div className="pt-3 border-t border-slate-800 text-center flex items-center justify-between text-xs text-slate-400">
            <span className="flex items-center gap-1.5">
              <Award className="w-4 h-4 text-amber-400" />
              Complete all 3 for maximum daily bank growth
            </span>
            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition-colors"
            >
              Done
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
