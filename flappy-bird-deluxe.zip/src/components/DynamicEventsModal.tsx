import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Flame, Sparkles, Coins, Zap, ShieldCheck, Sun, Clock, Compass, ChevronRight } from 'lucide-react';
import { DynamicEvent } from '../types/game';
import { DYNAMIC_EVENTS, EVENT_ROTATION_ORDER, getCurrentDynamicEvent } from '../constants/events';
import { sound } from '../services/audio';

interface DynamicEventsModalProps {
  onClose: () => void;
}

export function DynamicEventsModal({ onClose }: DynamicEventsModalProps) {
  const [currentEventData, setCurrentEventData] = useState(getCurrentDynamicEvent());

  // Real-time 1-second interval to update remaining timer
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentEventData(getCurrentDynamicEvent());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const { event: activeEvent, timeRemainingSeconds, progressPercent } = currentEventData;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const getEventIcon = (iconName: string, className = 'w-5 h-5') => {
    switch (iconName) {
      case 'Coins':
        return <Coins className={className} />;
      case 'Sparkles':
        return <Sparkles className={className} />;
      case 'Flame':
        return <Flame className={className} />;
      case 'ShieldCheck':
        return <ShieldCheck className={className} />;
      case 'Zap':
        return <Zap className={className} />;
      case 'Sun':
        return <Sun className={className} />;
      default:
        return <Sparkles className={className} />;
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 15 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-2xl p-6 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden text-slate-100"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-cyan-500/10 border border-cyan-500/20 rounded-xl">
                <Compass className="w-6 h-6 text-cyan-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
                  Atmospheric Events
                </h2>
                <p className="text-xs text-slate-400">Rotating planetary anomalies & flight modifiers</p>
              </div>
            </div>
            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto my-4 space-y-4 pr-1">
            {/* ACTIVE EVENT HERO CARD */}
            <div className="relative overflow-hidden rounded-xl border border-slate-700 bg-slate-800/80 p-4 shadow-xl">
              <div
                className="absolute top-0 right-0 w-32 h-32 blur-2xl opacity-20 pointer-events-none"
                style={{ backgroundColor: activeEvent.glowColor }}
              />

              <div className="flex items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <span className="flex h-2.5 w-2.5 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                  </span>
                  <span className="text-[11px] font-bold tracking-wider uppercase text-emerald-400">
                    Live Anomaly
                  </span>
                </div>
                <div className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-900/80 border border-slate-700 rounded-full text-xs font-mono text-cyan-300">
                  <Clock className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{formatTime(timeRemainingSeconds)}</span>
                </div>
              </div>

              <div className="flex items-start gap-3 my-2">
                <div
                  className={`p-3 rounded-xl bg-gradient-to-br ${activeEvent.bannerColor} text-slate-950 shadow-md`}
                >
                  {getEventIcon(activeEvent.icon, 'w-6 h-6')}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-slate-100">{activeEvent.name}</h3>
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-slate-900 text-cyan-300 rounded border border-slate-700">
                      {activeEvent.badge}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 font-medium mt-0.5">{activeEvent.tagline}</p>
                </div>
              </div>

              <p className="text-xs text-slate-400 bg-slate-900/50 p-2.5 rounded-lg border border-slate-800 mt-2">
                {activeEvent.description}
              </p>

              {/* Progress bar of current cycle */}
              <div className="mt-3">
                <div className="flex justify-between items-center text-[10px] text-slate-400 mb-1 font-mono">
                  <span>Cycle Progress</span>
                  <span>{Math.round(progressPercent)}%</span>
                </div>
                <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 transition-all duration-300"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>
            </div>

            {/* EVENT ROTATION DIRECTORY */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Event Directory (15-Min Cycles)
              </h4>
              <div className="space-y-2">
                {EVENT_ROTATION_ORDER.map((evtKey) => {
                  const ev = DYNAMIC_EVENTS[evtKey];
                  const isCurrent = ev.id === activeEvent.id;

                  return (
                    <div
                      key={ev.id}
                      className={`flex items-center justify-between p-2.5 rounded-lg border transition-all ${
                        isCurrent
                          ? 'bg-cyan-950/20 border-cyan-500/40 text-slate-100'
                          : 'bg-slate-850/40 border-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="p-1.5 rounded-md bg-slate-800 text-slate-300">
                          {getEventIcon(ev.icon, 'w-4 h-4')}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-200">{ev.name}</span>
                            <span className="text-[10px] font-medium text-slate-400">{ev.badge}</span>
                          </div>
                          <p className="text-[11px] text-slate-400 line-clamp-1">{ev.tagline}</p>
                        </div>
                      </div>

                      {isCurrent ? (
                        <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full">
                          ACTIVE
                        </span>
                      ) : (
                        <ChevronRight className="w-4 h-4 text-slate-600" />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="pt-3 border-t border-slate-800 flex justify-end">
            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium transition-colors"
            >
              Close
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
