import React from 'react';
import { sound } from '../services/audio';
import { Play, RotateCcw, Home, Settings } from 'lucide-react';

interface PauseModalProps {
  onResume: () => void;
  onRestart: () => void;
  onGoHome: () => void;
  onOpenSettings: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  onResume,
  onRestart,
  onGoHome,
  onOpenSettings,
}) => {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm pointer-events-auto select-none animate-in fade-in duration-150">
      <div className="w-full max-w-xs bg-slate-900 border-2 border-slate-700/90 rounded-3xl p-5 shadow-2xl flex flex-col items-center gap-4 text-center">
        <div>
          <h3 className="text-2xl font-black text-slate-100 uppercase tracking-wider font-['Fredoka']">
            GAME PAUSED
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">Take a breather, flyer!</p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5 w-full">
          <button
            onClick={() => {
              sound.playClick();
              onResume();
            }}
            className="w-full py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm uppercase font-['Fredoka'] tracking-wider shadow-md active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            <Play className="w-4 h-4 fill-slate-950" />
            <span>RESUME</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onRestart();
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs uppercase flex items-center justify-center gap-2 border border-slate-700 active:scale-95 transition-all"
          >
            <RotateCcw className="w-4 h-4 text-emerald-400" />
            <span>RESTART RUN</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onOpenSettings();
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs uppercase flex items-center justify-center gap-2 border border-slate-700 active:scale-95 transition-all"
          >
            <Settings className="w-4 h-4 text-indigo-400" />
            <span>SETTINGS</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onGoHome();
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-rose-950/40 hover:bg-rose-900/40 text-rose-300 font-bold text-xs uppercase flex items-center justify-center gap-2 border border-rose-800/40 active:scale-95 transition-all"
          >
            <Home className="w-4 h-4" />
            <span>QUIT TO MENU</span>
          </button>
        </div>
      </div>
    </div>
  );
};
