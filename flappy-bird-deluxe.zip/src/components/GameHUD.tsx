import { motion } from 'motion/react';
import { Pause, Volume2, VolumeX, Shield, Zap } from 'lucide-react';
import { BirdConfig, GameSettings, DynamicEvent } from '../types/game';

interface GameHUDProps {
  score: number;
  coins: number;
  bird: BirdConfig;
  hasShield: boolean;
  activeEvent: DynamicEvent | null;
  settings: GameSettings;
  onPause: () => void;
  onToggleSound: () => void;
}

export function GameHUD({
  score,
  coins,
  bird,
  hasShield,
  activeEvent,
  settings,
  onPause,
  onToggleSound,
}: GameHUDProps) {
  const isSoundActive = settings.sound.sfxEnabled;

  return (
    <div className="absolute inset-0 pointer-events-none p-4 flex flex-col justify-between select-none">
      {/* Top HUD Row */}
      <div className="flex items-start justify-between w-full">
        {/* Left Stats Display (Coins + Event Badge + Shield) */}
        <div className="flex flex-col gap-1.5 pointer-events-auto">
          {/* Run Coins Display */}
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="flex items-center gap-1.5 px-3 py-1 bg-slate-950/70 backdrop-blur-sm border border-amber-500/30 rounded-full shadow-md w-fit"
          >
            <span className="text-sm">🪙</span>
            <span className="font-extrabold text-amber-300 text-sm">{coins}</span>
            {bird.coinMultiplier > 1 && (
              <span className="text-[10px] font-bold text-amber-400 bg-amber-950 px-1 rounded border border-amber-700">
                {bird.coinMultiplier}x
              </span>
            )}
          </motion.div>

          {/* Active Dynamic Event Indicator */}
          {activeEvent && (
            <div className="flex items-center gap-1.5 px-2.5 py-0.5 bg-slate-950/80 backdrop-blur-sm border border-cyan-500/40 rounded-full shadow-md w-fit">
              <Zap className="w-3 h-3 text-cyan-400" />
              <span className="text-[10px] font-bold text-cyan-300 tracking-wide uppercase">
                {activeEvent.badge}
              </span>
            </div>
          )}

          {/* Shield Status */}
          {hasShield && (
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className="flex items-center gap-1 px-2.5 py-0.5 bg-sky-950/80 backdrop-blur-sm border border-sky-400/50 rounded-full text-[11px] font-bold text-sky-300 shadow-md w-fit"
            >
              <Shield className="w-3 h-3 text-sky-400 fill-sky-400/40" />
              <span>Shield Active</span>
            </motion.div>
          )}
        </div>

        {/* Big Classic Centered Score */}
        <div className="flex flex-col items-center">
          <motion.div
            key={score}
            initial={{ scale: 1.2 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.12 }}
            className="text-5xl font-black text-white drop-shadow-[0_4px_10px_rgba(0,0,0,0.9)] tracking-tight font-sans"
          >
            {score}
          </motion.div>
          {activeEvent?.doubleScoreMod && (
            <span className="text-[9px] font-black text-rose-300 tracking-wider uppercase bg-slate-950/85 px-2 py-0.5 rounded-full border border-rose-500/50 mt-1">
              2X SCORE
            </span>
          )}
        </div>

        {/* Top Right Controls (Sound & Pause) */}
        <div className="flex items-center gap-1.5 pointer-events-auto">
          <button
            onClick={onToggleSound}
            className="p-2 rounded-full bg-slate-950/70 backdrop-blur-sm border border-slate-700/80 text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="Toggle Sound"
          >
            {isSoundActive ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          <button
            onClick={onPause}
            className="p-2 rounded-full bg-slate-950/70 backdrop-blur-sm border border-slate-700/80 text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="Pause"
          >
            <Pause className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Subtle In-flight tap guide hint */}
      <div className="text-center pb-2 opacity-40 text-[11px] font-medium text-white drop-shadow">
        Tap or Press Space to Flap
      </div>
    </div>
  );
}
