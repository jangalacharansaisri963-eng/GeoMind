import { useState, useEffect, useCallback } from 'react';
import { GameState, BirdConfig, GameSettings, PlayerStats, LeaderboardEntry, DailyQuest, DynamicEvent } from './types/game';
import { getBirdById } from './constants/birds';
import { getThemeById } from './constants/themes';
import { getCurrentDynamicEvent } from './constants/events';
import { sound } from './services/audio';
import {
  getStoredStats,
  saveStoredStats,
  getStoredSettings,
  saveStoredSettings,
  getStoredLeaderboard,
  addLeaderboardScore,
} from './services/storage';
import { getStoredQuests, saveStoredQuests, updateQuestsWithRun } from './services/quests';

import { GameCanvas } from './components/GameCanvas';
import { StartMenu } from './components/StartMenu';
import { GameHUD } from './components/GameHUD';
import { GameOverModal } from './components/GameOverModal';
import { PauseModal } from './components/PauseModal';
import { ShopModal } from './components/ShopModal';
import { LeaderboardModal } from './components/LeaderboardModal';
import { SettingsModal } from './components/SettingsModal';
import { HowToPlayModal } from './components/HowToPlayModal';
import { DailyQuestsModal } from './components/DailyQuestsModal';
import { DynamicEventsModal } from './components/DynamicEventsModal';

export default function App() {
  // Persistence state
  const [stats, setStats] = useState<PlayerStats>(getStoredStats);
  const [settings, setSettings] = useState<GameSettings>(getStoredSettings);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>(getStoredLeaderboard);
  const [quests, setQuests] = useState<DailyQuest[]>(getStoredQuests);

  // Dynamic Event state
  const [currentEventInfo, setCurrentEventInfo] = useState(getCurrentDynamicEvent());
  const activeEvent: DynamicEvent = currentEventInfo.event;

  // Active game session state
  const [gameState, setGameState] = useState<GameState>('MENU');
  const [score, setScore] = useState<number>(0);
  const [runCoins, setRunCoins] = useState<number>(0);
  const [isNewHighScore, setIsNewHighScore] = useState<boolean>(false);
  const [hasShield, setHasShield] = useState<boolean>(false);
  const [completedQuestsInLastRun, setCompletedQuestsInLastRun] = useState<DailyQuest[]>([]);

  // Modals state
  const [isShopOpen, setIsShopOpen] = useState<boolean>(false);
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isHowToOpen, setIsHowToOpen] = useState<boolean>(false);
  const [isQuestsOpen, setIsQuestsOpen] = useState<boolean>(false);
  const [isEventsOpen, setIsEventsOpen] = useState<boolean>(false);

  // Current configurations
  const currentBird: BirdConfig = getBirdById(stats.selectedBirdId);
  const currentTheme = getThemeById(settings.graphics.themeId);

  // Count unclaimed completed quests
  const unclaimedQuestsCount = quests.filter((q) => q.completed && !q.claimed).length;

  // Sync Dynamic Event on a 1-second interval
  useEffect(() => {
    const timer = setInterval(() => {
      const updated = getCurrentDynamicEvent();
      // Notify player if event rotated
      if (updated.event.id !== currentEventInfo.event.id) {
        sound.playEventAlert();
      }
      setCurrentEventInfo(updated);
    }, 1000);
    return () => clearInterval(timer);
  }, [currentEventInfo.event.id]);

  // Initialize audio settings on mount
  useEffect(() => {
    sound.applySettings(settings.sound);
  }, []);

  // Save changes to storage
  useEffect(() => {
    saveStoredStats(stats);
  }, [stats]);

  useEffect(() => {
    saveStoredSettings(settings);
  }, [settings]);

  useEffect(() => {
    saveStoredQuests(quests);
  }, [quests]);

  // Start new run
  const handleStartGame = useCallback(() => {
    setScore(0);
    setRunCoins(0);
    setIsNewHighScore(false);
    setHasShield(currentBird.hasShield || activeEvent.freeShieldOnStart);
    setCompletedQuestsInLastRun([]);
    setGameState('PLAYING');
  }, [currentBird, activeEvent]);

  // Game over event from Canvas
  const handleGameOver = useCallback(
    (finalScore: number, finalCoins: number, pipesPassed: number, flaps: number) => {
      setGameState('GAMEOVER');

      const isNewBest = finalScore > stats.highScore;
      setIsNewHighScore(isNewBest);

      // Update quests progress
      const { updatedQuests, newlyCompleted } = updateQuestsWithRun(quests, {
        score: finalScore,
        coins: finalCoins,
        pipesPassed,
        flaps,
        birdId: currentBird.id,
      });

      setQuests(updatedQuests);
      setCompletedQuestsInLastRun(newlyCompleted);

      if (newlyCompleted.length > 0) {
        setTimeout(() => {
          sound.playQuestComplete();
        }, 600);
      }

      const updatedStats: PlayerStats = {
        ...stats,
        highScore: Math.max(stats.highScore, finalScore),
        totalCoins: stats.totalCoins + finalCoins,
        gamesPlayed: stats.gamesPlayed + 1,
        totalPipesPassed: stats.totalPipesPassed + pipesPassed,
        totalCoinsCollected: stats.totalCoinsCollected + finalCoins,
        totalFlaps: (stats.totalFlaps ?? 0) + flaps,
        completedQuestsCount: (stats.completedQuestsCount ?? 0) + newlyCompleted.length,
      };

      setStats(updatedStats);

      // If score > 0, register to leaderboard
      if (finalScore > 0) {
        const today = new Date().toISOString().split('T')[0];
        const updatedLeaderboard = addLeaderboardScore({
          playerName: settings.playerName,
          score: finalScore,
          coins: finalCoins,
          birdId: currentBird.id,
          date: today,
          themeId: settings.graphics.themeId,
        });
        setLeaderboard(updatedLeaderboard);
      }
    },
    [stats, settings, currentBird, quests]
  );

  // Score & Coin handlers
  const handleScoreUpdate = useCallback((newScore: number) => {
    setScore(newScore);
  }, []);

  const handleCoinCollect = useCallback((_earned: number, totalInRun: number) => {
    setRunCoins(totalInRun);
  }, []);

  const handleShieldUsed = useCallback(() => {
    setHasShield(false);
  }, []);

  // Claim Quest Reward
  const handleClaimQuest = useCallback(
    (questId: string) => {
      const targetQuest = quests.find((q) => q.id === questId);
      if (!targetQuest || targetQuest.claimed || !targetQuest.completed) return;

      const reward = targetQuest.rewardCoins;
      const updatedQuests = quests.map((q) =>
        q.id === questId ? { ...q, claimed: true } : q
      );

      setQuests(updatedQuests);
      setStats((prev) => ({
        ...prev,
        totalCoins: prev.totalCoins + reward,
      }));
    },
    [quests]
  );

  // Bird Shop actions
  const handleBuyBird = useCallback(
    (bird: BirdConfig) => {
      if (stats.totalCoins >= bird.price && !stats.unlockedBirds.includes(bird.id)) {
        setStats((prev) => ({
          ...prev,
          totalCoins: prev.totalCoins - bird.price,
          unlockedBirds: [...prev.unlockedBirds, bird.id],
          selectedBirdId: bird.id,
        }));
      }
    },
    [stats]
  );

  const handleEquipBird = useCallback((birdId: string) => {
    setStats((prev) => ({
      ...prev,
      selectedBirdId: birdId,
    }));
  }, []);

  // Quick sound toggle from HUD
  const handleToggleSound = useCallback(() => {
    sound.playClick();
    const updated = {
      ...settings,
      sound: {
        ...settings.sound,
        sfxEnabled: !settings.sound.sfxEnabled,
        bgmEnabled: !settings.sound.sfxEnabled,
      },
    };
    setSettings(updated);
    sound.applySettings(updated.sound);
  }, [settings]);

  // Reset data handler
  const handleResetData = useCallback(() => {
    sound.playClick();
    const freshStats: PlayerStats = {
      highScore: 0,
      totalCoins: 50,
      gamesPlayed: 0,
      totalPipesPassed: 0,
      totalCoinsCollected: 0,
      totalFlaps: 0,
      unlockedBirds: ['pip'],
      selectedBirdId: 'pip',
      completedQuestsCount: 0,
    };
    setStats(freshStats);
    saveStoredStats(freshStats);
    setIsSettingsOpen(false);
  }, []);

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-slate-950 flex items-center justify-center p-0 sm:p-4 font-sans">
      {/* Background ambient glow matching current theme and dynamic event */}
      <div
        className="absolute inset-0 opacity-25 pointer-events-none transition-colors duration-1000"
        style={{
          background: `radial-gradient(circle at 50% 50%, ${activeEvent.glowColor || currentTheme.skyTop} 0%, #020617 80%)`,
        }}
      />

      {/* Main Game Container */}
      <div className="relative w-full h-full max-w-[440px] max-h-[760px] flex flex-col items-center justify-center overflow-hidden rounded-none sm:rounded-3xl shadow-2xl border-0 sm:border-4 border-slate-800 bg-slate-900">
        {/* Core Canvas Gameplay Engine */}
        <GameCanvas
          bird={currentBird}
          theme={currentTheme}
          settings={settings}
          activeEvent={activeEvent}
          isPlaying={gameState === 'PLAYING'}
          isGameOver={gameState === 'GAMEOVER'}
          onScoreUpdate={handleScoreUpdate}
          onCoinCollect={handleCoinCollect}
          onGameOver={handleGameOver}
          onShieldUsed={handleShieldUsed}
        />

        {/* 1. START MENU OVERLAY */}
        {gameState === 'MENU' && (
          <StartMenu
            stats={stats}
            selectedBird={currentBird}
            activeEvent={activeEvent}
            unclaimedQuestsCount={unclaimedQuestsCount}
            onStartGame={handleStartGame}
            onOpenShop={() => setIsShopOpen(true)}
            onOpenLeaderboard={() => setIsLeaderboardOpen(true)}
            onOpenSettings={() => setIsSettingsOpen(true)}
            onOpenHowTo={() => setIsHowToOpen(true)}
            onOpenQuests={() => setIsQuestsOpen(true)}
            onOpenEvents={() => setIsEventsOpen(true)}
            onSelectBird={handleEquipBird}
          />
        )}

        {/* 2. IN-GAME HUD OVERLAY */}
        {gameState === 'PLAYING' && (
          <GameHUD
            score={score}
            coins={runCoins}
            bird={currentBird}
            hasShield={hasShield}
            activeEvent={activeEvent}
            settings={settings}
            onPause={() => setGameState('PAUSED')}
            onToggleSound={handleToggleSound}
          />
        )}

        {/* 3. PAUSE MODAL */}
        {gameState === 'PAUSED' && (
          <PauseModal
            onResume={() => setGameState('PLAYING')}
            onRestart={handleStartGame}
            onGoHome={() => setGameState('MENU')}
            onOpenSettings={() => setIsSettingsOpen(true)}
          />
        )}

        {/* 4. GAME OVER SUMMARY */}
        {gameState === 'GAMEOVER' && (
          <GameOverModal
            score={score}
            coinsEarned={runCoins}
            isNewHighScore={isNewHighScore}
            stats={stats}
            bird={currentBird}
            completedQuestsInRun={completedQuestsInLastRun}
            onRestart={handleStartGame}
            onGoHome={() => setGameState('MENU')}
            onOpenShop={() => setIsShopOpen(true)}
            onOpenLeaderboard={() => setIsLeaderboardOpen(true)}
            onOpenQuests={() => setIsQuestsOpen(true)}
          />
        )}
      </div>

      {/* MODAL DIALOGS */}
      {isQuestsOpen && (
        <DailyQuestsModal
          quests={quests}
          onClaimQuest={handleClaimQuest}
          onClose={() => setIsQuestsOpen(false)}
        />
      )}

      {isEventsOpen && (
        <DynamicEventsModal onClose={() => setIsEventsOpen(false)} />
      )}

      {isShopOpen && (
        <ShopModal
          stats={stats}
          selectedBird={currentBird}
          onClose={() => setIsShopOpen(false)}
          onBuyBird={handleBuyBird}
          onEquipBird={handleEquipBird}
        />
      )}

      {isLeaderboardOpen && (
        <LeaderboardModal
          entries={leaderboard}
          stats={stats}
          playerName={settings.playerName}
          onUpdatePlayerName={(name) => setSettings((s) => ({ ...s, playerName: name }))}
          onClose={() => setIsLeaderboardOpen(false)}
        />
      )}

      {isSettingsOpen && (
        <SettingsModal
          settings={settings}
          onUpdateSettings={setSettings}
          onResetData={handleResetData}
          onClose={() => setIsSettingsOpen(false)}
        />
      )}

      {isHowToOpen && <HowToPlayModal onClose={() => setIsHowToOpen(false)} />}
    </main>
  );
}
